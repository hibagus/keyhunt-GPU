#!/usr/bin/env python3
"""Capture the documented localhost launch/sync/execute/inspect/upload sequence."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import select
import signal
import socket
import subprocess
import tempfile

p=argparse.ArgumentParser()
p.add_argument('--repo',type=Path,required=True)
p.add_argument('--build',type=Path,required=True)
p.add_argument('--apache-root',required=True)
p.add_argument('--backend',required=True)
p.add_argument('--device',default='0')
p.add_argument('--report',type=Path,required=True)
a=p.parse_args();repo=a.repo.resolve();build=a.build.resolve()
report={'backend':a.backend,'passed':False,'commands':[],
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'binary_sha256':{n:hashlib.sha256((build/n).read_bytes()).hexdigest()
                         for n in ['keyhunt','keyhunt-worker','keyhunt-coordinator']}}
with tempfile.TemporaryDirectory(prefix='kh21-',dir='/var/tmp') as temp:
    demo=Path(temp)/'demo';state=demo/'alice-worker'
    with socket.socket() as s:
        s.bind(('127.0.0.1',0));port=s.getsockname()[1]
    command=['python3',str(repo/'tools/coordinator_local.py'),'--directory',str(demo),
             '--coordinator',str(build/'keyhunt-coordinator'),'--worker',str(build/'keyhunt-worker'),
             '--apache-root',a.apache_root,'--port',str(port)]
    with open(Path(temp)/'launcher.stderr','w+') as errors:
        process=subprocess.Popen(command,text=True,stdout=subprocess.PIPE,stderr=errors)
        try:
            assert select.select([process.stdout],[],[],60)[0], 'launcher readiness timeout'
            ready=json.loads(process.stdout.readline());assert ready['ready']
            report['launcher_command']=command;report['ready']=True
            def run(words):
                result=subprocess.run(words,text=True,capture_output=True,timeout=120)
                report['commands'].append(dict(command=words,exit_code=result.returncode,
                                               stdout=result.stdout,stderr=result.stderr))
                assert result.returncode==0, (words,result.stderr)
                return json.loads(result.stdout) if result.stdout.strip() else None
            worker=[str(build/'keyhunt-worker')]
            before=run(worker+['sync','--state-dir',str(state)])
            assert before['sent']
            run(['python3',str(repo/'tools/coordinator_worker.py'),'--state-dir',str(state),
                 '--backend',a.backend,'--worker',str(build/'keyhunt-worker'),
                 '--keyhunt',str(build/'keyhunt'),'--device-map','0='+a.device,'--once'])
            local=run(worker+['status','--state-dir',str(state)])
            assert local['outbox_bytes']>0 and any(q['activity']=='local-complete-awaiting-sync' for q in local['queues'])
            assert local['last_ack_server_time']==before['last_ack_server_time']
            after=run(worker+['sync','--state-dir',str(state)])
            assert after['sent'] and after['outbox_bytes']==0
            assert any(q['activity']=='server-acknowledged' for q in after['queues'])
            run([str(build/'keyhunt'),'state','check','--state-dir',str(state)])
            report['local_status']=local;report['acknowledged_status']=after
            report['supervisor']=json.loads((state/'supervisor.json').read_text())
            report['passed']=True
        except Exception as error:
            report['error']=repr(error)
        finally:
            process.send_signal(signal.SIGINT)
            try:process.communicate(timeout=30)
            except subprocess.TimeoutExpired:process.kill();process.communicate();report['passed']=False
            errors.seek(0);report['launcher_stderr']=errors.read()
            report['launcher_exit_code']=process.returncode
            report['passed']=report['passed'] and process.returncode==0
    # The CLI owns its Apache/coordinator children and drains them on SIGINT.
    # Closing this fixture removes its disposable certificates and journals.
a.report.write_text(json.dumps(report,indent=2)+'\n')
print(('PASS' if report['passed'] else 'FAIL')+' '+a.backend+' localhost operation')
if not report['passed']:print(report.get('error',report['launcher_stderr']))
raise SystemExit(0 if report['passed'] else 1)
