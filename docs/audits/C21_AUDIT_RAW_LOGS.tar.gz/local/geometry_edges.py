#!/usr/bin/env python3
"""CPU-oracle boundary checks for the two supported BSGS launch geometries."""
import argparse
import hashlib
import importlib.util
import json
import pathlib
import subprocess
import tempfile

p=argparse.ArgumentParser()
p.add_argument('--source',type=pathlib.Path,required=True)
p.add_argument('--build',type=pathlib.Path,required=True)
p.add_argument('--backend',required=True)
p.add_argument('--output',type=pathlib.Path,required=True)
a=p.parse_args()
spec=importlib.util.spec_from_file_location('oracle',a.source/'tests/oracle/model.py')
oracle=importlib.util.module_from_spec(spec);spec.loader.exec_module(oracle)
binary=a.build/'keyhunt';width=257*524288
report=dict(passed=False,backend=a.backend,runs=[],commands=[],binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
            script_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest())
with tempfile.TemporaryDirectory(prefix='kh-c21-geometry-',dir='/var/tmp') as temporary:
    root=pathlib.Path(temporary);table=root/'babies.khb';targets=root/'targets'
    def run(args):
        command=[str(binary),*map(str,args)]
        r=subprocess.run(command,text=True,capture_output=True,timeout=120)
        report['commands'].append(dict(command=command,exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr))
        if r.returncode:raise ValueError(r.stderr)
        return [json.loads(line) for line in r.stdout.splitlines()]
    run(['bsgs-table','build','--m','257','--output',table])
    cases=[('tile-edge',1,2*width+8,[width,width+1]),
           ('range-tail',1,2*width+8,[1,2*width+7]),
           ('near-order',oracle.N-2*width-7,oracle.N,[oracle.N-2*width-7,oracle.N-1])]
    for name,begin,end,seeds in cases:
        public={k:oracle.encode(oracle.multiply(k)) for k in seeds}
        targets.write_text('\n'.join(public.values())+'\n')
        for variant,giants,batch in [('baseline',16384,64),('candidate',524288,2)]:
            rows=run(['bsgs','--backend',a.backend,'--device','0','--range',f'{begin:x}:{end:x}',
                      '--targets',targets,'--table',table,'--giant-batch',giants,'--target-batch',batch])
            summary=rows[-1];cursor=begin;matches=[];groups=set();steps=0
            for row in rows:
                if row['type']=='batch':
                    if row['overflow']:raise ValueError('unexpected overflow')
                    groups.add(row['group_size']);steps+=row['device_steps']
                    matches.extend((int(m['scalar'],16),m['public_key']) for m in row['matches'])
                if row['type']=='tile':
                    if int(row['begin'],16)!=cursor:raise ValueError('coverage gap/overlap')
                    cursor=int(row['end_exclusive'],16)
            if not summary['complete'] or cursor!=end or int(summary['verified_scalars'],16)!=end-begin:
                raise ValueError('incomplete coverage')
            if sorted(matches)!=sorted(public.items()):raise ValueError('wrong CPU-oracle match set')
            if steps!=((end-begin+256)//257)*2:raise ValueError('wrong target-giant count')
            report['runs'].append(dict(case=name,variant=variant,begin=hex(begin),end_exclusive=hex(end),
                expected_matches=[(hex(k),v) for k,v in public.items()],actual_groups=sorted(groups),summary=summary))
    report['passed']=True
a.output.write_text(json.dumps(report,indent=2)+'\n')
print('PASS',a.backend,'six geometry/oracle boundary runs')
