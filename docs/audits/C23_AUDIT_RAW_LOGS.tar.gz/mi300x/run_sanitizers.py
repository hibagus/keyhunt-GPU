import pathlib,subprocess,json,os,time
r=pathlib.Path(__file__).resolve().parent;b=r/'sanitizers';cmd=json.loads((r/'cpu-build.json').read_text())[0]['command'];cmd[cmd.index('-B')+1]=str(b);cmd[cmd.index('-DCMAKE_BUILD_TYPE=Release')]='-DCMAKE_BUILD_TYPE=Debug';cmd+=['-DKEYHUNT_ENABLE_SANITIZERS=ON','-DKEYHUNT_ENABLE_LTO=OFF']
expr='^(portable_hash160_oracle|portable_keccak_oracle|portable_minikey_oracle|portable_glv_oracle|scalar_random_window_oracle|scalar_batch_oracle|storage_scalar_random_window|storage_minikey_random_window|storage_bsgs_random_window)$'
env=dict(os.environ,KEYHUNT_KECCAK_ORACLE_ROOT='/var/tmp/keyhunt-c23-ethereum-oracle',TMPDIR='/var/tmp',ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1');runs=[]
def run(stage,cmd):
 start=time.monotonic()
 with (r/'logs'/f'sanitizers-{stage}.log').open('w') as f:rc=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env).returncode
 runs.append(dict(stage=stage,command=cmd,exit_code=rc,seconds=time.monotonic()-start));(r/'sanitizers.json').write_text(json.dumps(runs,indent=2)+'\n');print(stage,rc,flush=True)
 if rc:raise SystemExit(rc)
run('configure',cmd)
selection=json.loads(subprocess.check_output(['ctest','--test-dir',str(b),'--show-only=json-v1','-R',expr]));(r/'sanitizers-selection.json').write_text(json.dumps(selection,indent=2)+'\n');targets=sorted({pathlib.Path(word).name for test in selection['tests'] for word in next(t for t in json.loads((r/'cpu-selection.json').read_text())['tests'] if t['name']==test['name'])['command'] if word.startswith(str(r/'cpu')+'/') and not word.endswith('.json')});print('targets',targets,flush=True)
run('build',['cmake','--build',str(b),'--parallel','10','--target',*targets]);run('tests',['ctest','--test-dir',str(b),'--output-on-failure','--parallel','6','-R',expr,'--output-junit',str(r/'sanitizers-tests.xml')])
