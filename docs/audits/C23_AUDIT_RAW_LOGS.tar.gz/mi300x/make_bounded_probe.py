from pathlib import Path
r=Path(__file__).resolve().parent
s=(r/'minikey_probe.hip').read_text();orig=(r/'source/kernels/search/minikeys.h').read_text();body=orig[orig.index('__global__ void minikeys_direct'):orig.rindex('} // namespace')]
body=body.replace('__global__ void minikeys_direct','__global__ __launch_bounds__(128) void minikeys_bounded')
s=s.replace('namespace keyhunt::gpu {','namespace keyhunt::gpu {\n'+body,1)
s=s.replace('__global__ void pack_minikeys','__global__ __launch_bounds__(128) void pack_minikeys').replace('__global__ void finish_minikeys','__global__ __launch_bounds__(32) void finish_minikeys')
s=s.replace('const char* names[]={"baseline","packed-direct","packed-glv"}', 'const char* names[]={"baseline","bounded","bounded-packed-direct","bounded-packed-glv"}')
s=s.replace('order<3','order<4').replace('(round+order)%3','(round+order)%4')
s=s.replace('if(kind)', 'if(kind>=2)')
line=next(v for v in s.splitlines() if 'if(kind==0){gpuLaunchKernelGGL' in v)
s=s.replace(line,line+'\n  '+line.strip().replace('if(kind==0)','else if(kind==1)').replace('gpu::minikeys_direct','gpu::minikeys_bounded'))
s=s.replace('if(kind==1){gpuLaunchKernelGGL(gpu::finish_minikeys','if(kind==2){gpuLaunchKernelGGL(gpu::finish_minikeys')
s=s.replace('{"cases",Json::array()}', '{"cases",Json::array()},{"variants",{"baseline","bounded","bounded-packed-direct","bounded-packed-glv"}}')
(r/'bounded_minikey_probe.hip').write_text(s)
