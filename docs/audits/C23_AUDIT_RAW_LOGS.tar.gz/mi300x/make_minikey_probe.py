from pathlib import Path
r=Path(__file__).resolve().parent;s=r/'source'
original=(s/'kernels/search/minikeys.h').read_text()
body=original.split('        Point point;')[1].split('\n    }\n    atomicAdd')[0]
body='Point point;'+body
body=body.replace('!public_key(point,scalar)', '!(UseGlv?public_key_glv(point,scalar):public_key(point,scalar))')
header=r'''// Audit-only experiment. Production headers and binaries are unchanged.
#include "runtime.h"
#include "minikeys.h"
#include "common/glv.h"
#include "keyhunt/core/minikey_search.h"
#include <nlohmann/json.hpp>
#include <algorithm>
#include <chrono>
#include <iostream>
#include <set>
#include <thread>
using namespace keyhunt;
using Json=nlohmann::json;
using core::UInt256;
using backend::gpu_check;
namespace keyhunt::gpu {
struct Packed{Scalar scalar;uint64_t offset;};
__global__ void pack_minikeys(Scalar begin,uint64_t count,bool reverse,unsigned length,
 Packed* packed,unsigned* valid,MinikeysCounters* counters){
 const uint64_t offset=uint64_t(blockIdx.x)*blockDim.x+threadIdx.x;if(offset>=count)return;
 uint64_t carry=reverse?count-1-offset:offset;
 for(unsigned i=0;i<8;++i){const uint64_t sum=uint64_t(begin.limb[i])+uint32_t(carry);begin.limb[i]=uint32_t(sum);carry=(carry>>32)+(sum>>32);}
 uint8_t text[31];Scalar scalar;
 if(carry||!minikey_text(begin,length,text)){atomicExch(&counters->invalid,1U);return;}
 if(minikey_private(text,length,scalar)){
  const unsigned slot=atomicAdd(valid,1U);
  if(slot>=count){atomicExch(&counters->invalid,1U);return;}
  packed[slot]={scalar,offset};
 }
 atomicAdd(&counters->steps,1ULL);
}
template<bool UseGlv> __global__ void finish_minikeys(const Packed* packed,const unsigned* valid,unsigned length,uint8_t encodings,
 const MinikeysDeviceTarget* targets,uint32_t target_count,core::XPointCandidate* output,uint32_t capacity,MinikeysCounters* counters){
 for(unsigned at=blockIdx.x*blockDim.x+threadIdx.x;at<*valid;at+=gridDim.x*blockDim.x){
  const auto scalar=packed[at].scalar;const auto offset=packed[at].offset;
'''
footer=r'''
 }
}
}
void require(bool condition,const char* reason){if(!condition)throw std::runtime_error(reason);}
void increment(std::string& text){const std::string alphabet="123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
 for(size_t i=text.size()-1;i>0;--i){auto at=alphabet.find(text[i]);if(at<57){text[i]=alphabet[at+1];return;}text[i]='1';}
 throw std::runtime_error("fixture exceeds minikey domain");}
struct Valid{uint64_t offset;core::MinikeyTarget compressed,uncompressed;};
Json run(int device,const std::string& initial,uint64_t count,bool reverse,uint32_t cap,bool measured){
 core::XPointVerifier verifier;std::vector<Valid> valid;std::string text=initial;
 for(uint64_t offset=0;offset<count;++offset){
  if(const auto scalar=core::minikey_scalar(text)){
   const auto point=verifier.derive(*scalar);
   valid.push_back({offset,core::minikey_target(initial.size(),core::hash160_target(point,1)),core::minikey_target(initial.size(),core::hash160_target(point,2))});
  }
  if(offset+1<count)increment(text);
 }
 std::vector<core::MinikeyTarget> values;
 if(!valid.empty()){
  for(size_t i=0;i<valid.size();++i)if(!measured||i==0||i+1==valid.size()){
   values.push_back(valid[i].compressed);values.push_back(valid[i].uncompressed);
  }
 }else{
  const auto scalar=*core::minikey_scalar("SzavMBLoXU6kDrqtUVmffv");
  values.push_back(core::minikey_target(initial.size(),core::hash160_target(verifier.derive(scalar),1)));
 }
 core::MinikeyTargets targets(values);std::set<std::pair<uint64_t,uint32_t>> expected;
 for(const auto& row:valid)for(const auto& value:{row.compressed,row.uncompressed}){
  auto at=std::lower_bound(targets.values().begin(),targets.values().end(),value);
  if(at!=targets.values().end()&&*at==value)expected.emplace(reverse?count-1-row.offset:row.offset,uint32_t(at-targets.values().begin()));
 }
 const auto bytes=core::minikey_ordinal(initial).bytes();const auto begin=gpu::scalar_from_bytes(bytes.data());
 gpuStream_t stream{};gpuEvent_t start{},middle{},end{};
 gpu::MinikeysDeviceTarget* dt=nullptr;core::XPointCandidate* output=nullptr;gpu::Packed* packed=nullptr;
 gpu::MinikeysCounters* counters=nullptr;unsigned* admitted=nullptr;
 auto check=[](gpuError_t status){gpu_check(status,"audit minikey GPU operation");};
 check(gpuSetDevice(device));check(gpuStreamCreateWithFlags(&stream,gpuStreamNonBlocking));check(gpuEventCreate(&start));check(gpuEventCreate(&middle));check(gpuEventCreate(&end));
 check(gpuMalloc(&dt,targets.values().size()*sizeof(*dt)));check(gpuMemcpy(dt,targets.values().data(),targets.values().size()*sizeof(*dt),gpuMemcpyHostToDevice));
 check(gpuMalloc(&output,(cap+1)*sizeof(*output)));check(gpuMalloc(&packed,(count+1)*sizeof(*packed)));check(gpuMalloc(&counters,sizeof(*counters)));check(gpuMalloc(&admitted,sizeof(*admitted)));
 check(gpuMemset(packed+count,0xa5,sizeof(*packed)));
 Json samples=Json::array();const char* names[]={"baseline","packed-direct","packed-glv"};
 for(unsigned round=0;round<(measured?11U:1U);++round)for(unsigned order=0;order<3;++order){
  unsigned kind=(round+order)%3;std::vector<core::XPointCandidate> host(cap+1);gpu::MinikeysCounters stats{};unsigned actual=0;
  auto wall=std::chrono::steady_clock::now();
  check(gpuMemsetAsync(output,0xa5,(cap+1)*sizeof(*output),stream));check(gpuMemsetAsync(counters,0,sizeof(*counters),stream));
  if(kind)check(gpuMemsetAsync(admitted,0,sizeof(*admitted),stream));
  check(gpuEventRecord(start,stream));
  if(kind==0){gpuLaunchKernelGGL(gpu::minikeys_direct,dim3((count+127)/128),dim3(128),0,stream,begin,count,reverse,unsigned(initial.size()),targets.encodings(),dt,uint32_t(targets.values().size()),output,cap,counters);}
  else{
   gpuLaunchKernelGGL(gpu::pack_minikeys,dim3((count+127)/128),dim3(128),0,stream,begin,count,reverse,unsigned(initial.size()),packed,admitted,counters);
   check(gpuGetLastError());check(gpuEventRecord(middle,stream));
   if(kind==1){gpuLaunchKernelGGL(gpu::finish_minikeys<false>,dim3(256),dim3(32),0,stream,packed,admitted,unsigned(initial.size()),targets.encodings(),dt,uint32_t(targets.values().size()),output,cap,counters);}
   else{gpuLaunchKernelGGL(gpu::finish_minikeys<true>,dim3(256),dim3(32),0,stream,packed,admitted,unsigned(initial.size()),targets.encodings(),dt,uint32_t(targets.values().size()),output,cap,counters);}
  }
  check(gpuGetLastError());check(gpuEventRecord(end,stream));check(gpuEventSynchronize(end));
  float kernel=0,filter=0;check(gpuEventElapsedTime(&kernel,start,end));if(kind)check(gpuEventElapsedTime(&filter,start,middle));
  check(gpuMemcpy(&stats,counters,sizeof(stats),gpuMemcpyDeviceToHost));check(gpuMemcpy(host.data(),output,host.size()*sizeof(*output),gpuMemcpyDeviceToHost));
  if(kind)check(gpuMemcpy(&actual,admitted,sizeof(actual),gpuMemcpyDeviceToHost));
  const double wall_ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-wall).count();
  require(stats.steps==count&&!stats.invalid,"incomplete/invalid batch");
  require(stats.candidates==expected.size()&&bool(stats.overflow)==(expected.size()>cap),"candidate count/overflow mismatch");
  for(const auto byte:std::vector<uint8_t>((uint8_t*)&host[cap],(uint8_t*)(&host[cap]+1)))require(byte==0xa5,"output canary damaged");
  if(kind){require(actual==valid.size(),"packed count differs from full CPU enumeration");gpu::Packed guard;check(gpuMemcpy(&guard,packed+count,sizeof(guard),gpuMemcpyDeviceToHost));for(const auto byte:std::vector<uint8_t>((uint8_t*)&guard,(uint8_t*)(&guard+1)))require(byte==0xa5,"scratch canary damaged");}
  {std::set<std::pair<uint64_t,uint32_t>> found;
   for(unsigned i=0;i<std::min<uint64_t>(stats.candidates,cap);++i){require(!host[i].reserved,"reserved bytes set");require(found.emplace(host[i].offset,host[i].target).second,"duplicate result");require(expected.count({host[i].offset,host[i].target}),"unexpected result");}
   if(!stats.overflow)require(found==expected,"full CPU relation set differs");
  }
  if(!measured||round>=2)samples.push_back({{"variant",names[kind]},{"round",measured?round-2:round},{"order",order},{"kernel_ms",kernel},{"filter_ms",filter},{"wall_ms",wall_ms},{"steps",stats.steps},{"matches",stats.candidates},{"overflow",bool(stats.overflow)}});
 }
 check(gpuFree(dt));check(gpuFree(output));check(gpuFree(packed));check(gpuFree(counters));check(gpuFree(admitted));check(gpuEventDestroy(start));check(gpuEventDestroy(middle));check(gpuEventDestroy(end));check(gpuStreamDestroy(stream));
 return {{"initial",initial},{"targets",targets.values()},{"expected_relations",expected},{"length",initial.size()},{"begin",core::minikey_ordinal(initial).hex()},{"count",count},{"reverse",reverse},{"capacity",cap},{"cpu_admitted",valid.size()},{"expected_matches",expected.size()},{"scratch_bytes",(count+1)*sizeof(gpu::Packed)},{"measured",measured},{"samples",samples}};
}
int main(int argc,char** argv){try{
 int device=argc>1?std::stoi(argv[1]):0;bool smoke=argc>2&&std::string(argv[2])=="smoke";Json report{{"device",device},{"passed",false},{"cases",Json::array()}};
 for(const std::string text:{"SzavMBLoXU6kDrqtUVmffv","S6c56bnXQiBjk9mqSYE7ykVQ7NzrRy"}){
  for(bool reverse:{false,true}){
   report["cases"].push_back(run(device,std::string("S")+std::string(text.size()-1,'1'),1,reverse,128,false));
   report["cases"].push_back(run(device,core::minikey_text(core::minikey_space_end(text.size()).subtract(UInt256(129)),text.size()),129,reverse,128,false));
   for(uint64_t count:{1,31,32,33,127,128,129,4097})report["cases"].push_back(run(device,text,count,reverse,128,false));
   report["cases"].push_back(run(device,text,4097,reverse,2,false));
  }
  if(!smoke)for(uint64_t count:{65536,1048576})report["cases"].push_back(run(device,text,count,false,16,true));
 }
 report["passed"]=true;std::cout<<report.dump(2)<<'\n';
}catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}}
'''
(r/'minikey_probe.hip').write_text(header+body+footer)
