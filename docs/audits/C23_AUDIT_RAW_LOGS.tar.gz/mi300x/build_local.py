import pathlib,subprocess,json,time,concurrent.futures
r=pathlib.Path(__file__).resolve().parent
base=json.loads(pathlib.Path('/tmp/keyhunt-c22-audit-u0d52ucm/builds.json').read_text())
def build(name):
 old=next(x['command'] for x in base if x['build']==name and x['stage']=='configure');cmd=[str(r/'source') if x.endswith('/keyhunt-c22-audit-u0d52ucm/source') else str(r/name) if x.endswith('/keyhunt-c22-audit-u0d52ucm/'+name) else x for x in old];results=[]
 for stage,args in [('configure',cmd),('build',['cmake','--build',str(r/name),'--parallel','8'])]:
  start=time.monotonic()
  with (r/'logs'/f'{name}-{stage}.log').open('w') as f:rc=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT).returncode
  results.append(dict(stage=stage,command=args,exit_code=rc,seconds=time.monotonic()-start));(r/f'{name}-build.json').write_text(json.dumps(results,indent=2)+'\n');print(name,stage,rc,flush=True)
  if rc:return rc
 return 0
with concurrent.futures.ThreadPoolExecutor(2) as pool: codes=list(pool.map(build,['cpu','hip']))
raise SystemExit(max(codes))
