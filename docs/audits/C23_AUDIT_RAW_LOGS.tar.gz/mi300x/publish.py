from pathlib import Path
import datetime,hashlib,json,shutil,tarfile,xml.etree.ElementTree as ET
r=Path(__file__).resolve().parent;remote=r/'raw-cuda';repo=Path('/home/bagus/keyhunt-GPU');out=repo/'docs/audits'
def read(p):return json.loads(p.read_text())
def write(name,value):
 p=out/name;p.write_text(json.dumps(value,indent=2)+'\n');return p
def fingerprint(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
tests={}
for backend,root in [('cpu',r),('hip',r),('cuda',remote),('sanitizers',r)]:
 xml=ET.parse(root/(backend+'-tests.xml')).getroot();expected=dict(cpu=195,hip=49,cuda=48,sanitizers=9)[backend]
 assert int(xml.attrib['tests'])==expected and all(int(xml.attrib[x])==0 for x in ['failures','disabled','skipped'])
 record=read(root/(backend+'-tests.json')) if backend!='sanitizers' else read(r/'sanitizers.json')[-1]
 assert record['exit_code']==0
 tests[backend]=dict(count=expected,passed=expected,seconds=record['seconds'],command=record['command'],junit=xml.attrib)
post=read(remote/'post-cuda.json');assert len(post)==5 and all(v['exit_code']==0 for v in post[:4]) and post[-1]['exit_code']==97
post_bound=read(remote/'post-bounded-cuda.json');assert len(post_bound)==5 and all(v['exit_code']==0 for v in post_bound)
initial_memcheck=(remote/'logs/memcheck-production.log').read_text();assert 'ERROR SUMMARY: 6 errors' in initial_memcheck and initial_memcheck.count('CUDA API Error: Invalid device number -1')==2 and initial_memcheck.count('Program hit cudaErrorInvalidDevice')==4
for name in ['experiment','production-api-suppressed','bounded-experiment']:
 p=remote/'logs'/('memcheck-'+name+'.log');assert 'ERROR SUMMARY: 0 errors' in p.read_text()
minikey={b:dict(measurement=read(root/('minikey-'+b+'.json')),verification=read(r/('minikey-'+b+'-summary.json'))) for b,root in [('hip',r),('cuda',remote)]}
assert all(v['measurement']['passed'] and v['verification']['passed'] and v['verification']['cases_checked']==48 for v in minikey.values())
glv={b:read(root/('glv-'+b+'.json')) for b,root in [('hip',r),('cuda',remote)]}
evidence=read(r/'evidence.json');assert all('fresh-'+b in evidence['glv'] for b in ['hip','cuda'])
bounds={b:dict(measurement=read(root/('bounded-minikey-'+b+'.json')),verification=read(r/('bounded-minikey-'+b+'-summary.json'))) for b,root in [('hip',r),('cuda',remote)]}
assert all(v['measurement']['passed'] and v['verification']['passed'] and v['verification']['cases_checked']==48 for v in bounds.values())
write('C23_AUDIT_BOUNDS.json',bounds)
write('C23_AUDIT_MINIKEY.json',minikey);write('C23_AUDIT_GLV.json',glv);write('C23_AUDIT_EVIDENCE.json',evidence)
text=(r/'report-template.md').read_text();table=['| Build/gate | Result | Elapsed |','| --- | --- | --- |']
for b,label in [('cpu','CPU release, complete CTest suite'),('hip','MI300X HIP release, selected CTest suite'),('cuda','H200 CUDA release, selected CTest suite'),('sanitizers','Host ASan/UBSan, selected gates')]:
 t=tests[b];table.append(f"| {label} | {t['passed']}/{t['count']} passed | {t['seconds']:.2f} s |")
text=text.replace('@TEST_TABLE@','\n'.join(table))
text=text.replace('@MEMCHECK@',"""Three final H200 Compute Sanitizer memcheck runs cover the production minikey
executor test and the 44 correctness cases in each audit experiment; all report
zero errors. The first production invocation returned 97 with six expected CUDA
API diagnostics: the test deliberately constructs device `-1` once per length
and later clears each runtime error. Its original log is retained. A rerun uses
`--report-api-errors no`, leaving memory-access checking enabled; this is an
explicit qualification, not a claim that the unfiltered invocation passed.
[NVIDIA documents the API-reporting control separately from memcheck](https://docs.nvidia.com/compute-sanitizer/ComputeSanitizer/index.html#cuda-api-error-checking).
The experiments keep default API reporting. No full device racecheck/synccheck
matrix is claimed.""")
table=['| GPU | Length | Ordinals | Baseline ms | Packed direct ms | Packed GLV ms | Packing gain | Packing + GLV gain |','| --- | --- | --- | --- | --- | --- | --- | --- |']
for backend,name in [('hip','MI300X'),('cuda','H200')]:
 for w in minikey[backend]['verification']['cases']:
  if not w['measured']:continue
  m=w['medians'];p=w['paired_speedup'];table.append(f"| {name} | {w['length']} | {w['count']:,} | {m['baseline']['kernel_ms']:.3f} | {m['packed-direct']['kernel_ms']:.3f} | {m['packed-glv']['kernel_ms']:.3f} | {p['packed-direct']['kernel_ms']['median']:.3f}× | {p['packed-glv']['kernel_ms']['median']:.3f}× |")
text=text.replace('@MINIKEY_TABLE@','\n'.join(table))
table=['| GPU | Length | Ordinals | Original ms | 128-thread bound ms | Paired speedup |','| --- | --- | --- | --- | --- | --- |']
for backend,name in [('hip','MI300X'),('cuda','H200')]:
 for w in bounds[backend]['verification']['cases']:
  if w['measured'] and w['count']==1048576:
   m=w['medians'];gain=w['paired_speedup']['bounded']['kernel_ms']['median'];table.append(f"| {name} | {w['length']} | 1,048,576 | {m['baseline']['kernel_ms']:.3f} | {m['bounded']['kernel_ms']:.3f} | {gain:.3f}× |")
text=text.replace('@BOUNDS_TABLE@','\n'.join(table))
# Interpretation is authored after inspecting both devices; never infer an
# unconditional recommendation from a numeric threshold in this generator.
text=text.replace('@MINIKEY_INTERPRETATION@',(r/'minikey-interpretation.txt').read_text().strip())
table=['| GPU | Scalar region | GLV versus direct | GLV versus stepped |','| --- | --- | --- | --- |']
for backend,name in [('hip','MI300X'),('cuda','H200')]:
 for region in ['low','bit128','bit192','dense256','order']:
  rows=[v for v in evidence['glv']['fresh-'+backend] if v['region']==region]
  ranges=[]
  for metric in ['direct_over_glv','stepped_over_glv']:
   nums=[v[metric] for v in rows];ranges.append(f'{min(nums):.2f}–{max(nums):.2f}×')
  table.append(f"| {name} | `{region}` | {' | '.join(ranges)} |")
text=text.replace('@GLV_TABLE@','\n'.join(table));assert '@' not in text
(out/'C23_AUDIT.md').write_text(text)
# Refresh derived/local inputs after the final verification, excluding builds,
# credentials, databases and binaries by construction.
local=r/'raw-local'
for p in r.iterdir():
 if p.is_file() and p.suffix in ('.json','.xml','.py','.hip'):
  shutil.copy2(p,local/p.name)
shutil.copytree(r/'logs',local/'logs',dirs_exist_ok=True)
for name in ['report-template.md','minikey-interpretation.txt']:
 shutil.copy2(r/name,local/name)
for name in ['audit_c23.py','audit_c23_minikey.py']:
 shutil.copy2(repo/'tools'/name,local/name)
archive=out/'C23_AUDIT_RAW_LOGS.tar.gz';members={}
with tarfile.open(archive,'w:gz') as tar:
 for label,root in [('mi300x',local),('h200',remote)]:
  for p in sorted(root.rglob('*')):
   if p.is_file():
    name=label+'/'+str(p.relative_to(root));members[name]=fingerprint(p);tar.add(p,arcname=name,recursive=False)
manifest=dict(passed=True,date='2026-10-02',source='2a254bdba3f0c4d22401ca35387d320df1ad54cb',scope='C23 documented exact GPU modes and traversals; focused fresh GPU gates, complete CPU release suite; audit-only performance prototype',tests=tests,host_sanitizer_environment=dict(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1'),hosts=dict(mi300x=read(r/'capture.json'),h200=read(remote/'capture.json')),builds=dict(cpu=read(r/'cpu-build.json'),hip=read(r/'hip-build.json'),cuda=read(remote/'build.json'),sanitizers=read(r/'sanitizers.json')),cuda_post_tests=post,cuda_followup=post_bound,expected_negative_diagnostics=dict(run='memcheck-production',exit_code=97,errors=6,reason='two deliberately invalid device -1 constructions plus returned/cleared CUDA errors',followup='memcheck-production-api-suppressed'),artifacts={p.name:fingerprint(p) for p in [out/'C23_AUDIT.md',out/'C23_AUDIT_MINIKEY.json',out/'C23_AUDIT_BOUNDS.json',out/'C23_AUDIT_GLV.json',out/'C23_AUDIT_EVIDENCE.json',archive]},tools={name:fingerprint(repo/name) for name in ['tools/audit_c23.py','tools/audit_c23_minikey.py']},raw_members=members)
write('C23_AUDIT_VALIDATION.json',manifest)
print('published',len(members),'raw files',archive.stat().st_size,'compressed bytes')
