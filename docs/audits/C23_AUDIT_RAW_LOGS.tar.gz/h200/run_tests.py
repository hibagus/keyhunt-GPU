import pathlib,subprocess,json,time,os,concurrent.futures,argparse
p=argparse.ArgumentParser();p.add_argument('--root',type=pathlib.Path,required=True);p.add_argument('--backend',choices=['cpu','hip','cuda'],required=True);a=p.parse_args();r=a.root;name=a.backend
parts=[name+'_', '(scalar_random_window_oracle|scalar_batch_oracle|minikey_random_window_oracle|bsgs_random_window_plan_oracle)$','(scalar_random_window_strides_reverse_cli|scalar_random_window_orbits_forward_cli|minikeys_random_window_cli|bsgs_random_window_search_cli)$','(checkpoint_scalar_random_window_reverse|checkpoint_scalar_random_window_pause|checkpoint_minikeys_random_window_cli|bsgs_random_window_recovery_cli)$','(coordinator_scalar_random_window_reverse_cli|coordinator_minikey_random_window_cli|coordinator_bsgs_random_window_cli|coordinator_https_worker|coordinator_offline_cli|coordinator_cuda_contexts)$']
cmd=['ctest','--test-dir',str(r/name),'--output-on-failure','--parallel','8','--output-junit',str(r/f'{name}-tests.xml')]
if name!='cpu':cmd+=['-R','^('+'|'.join(parts)+')']
selection=['ctest','--test-dir',str(r/name),'--show-only=json-v1']+(cmd[cmd.index('-R'):] if '-R' in cmd else [])
(r/f'{name}-selection.json').write_bytes(subprocess.check_output(selection))
env=dict(os.environ,KEYHUNT_KECCAK_ORACLE_ROOT='/var/tmp/keyhunt-c23-ethereum-oracle',TMPDIR='/var/tmp')
start=time.monotonic()
with (r/'logs'/f'{name}-tests.log').open('w') as f:rc=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env).returncode
(r/f'{name}-tests.json').write_text(json.dumps(dict(command=cmd,exit_code=rc,seconds=time.monotonic()-start,environment={k:env[k] for k in ['KEYHUNT_KECCAK_ORACLE_ROOT','TMPDIR']}),indent=2)+'\n');print(name,rc,flush=True);raise SystemExit(rc)
