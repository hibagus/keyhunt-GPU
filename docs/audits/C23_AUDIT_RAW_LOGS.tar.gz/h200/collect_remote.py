from pathlib import Path
import hashlib,json,tarfile
r=Path(__file__).resolve().parent
assert json.loads((r/'cuda-tests.json').read_text())['exit_code']==0
assert all(x['exit_code']==0 for x in json.loads((r/'post-cuda.json').read_text())[:4])
assert all(x['exit_code']==0 for x in json.loads((r/'post-bounded-cuda.json').read_text()))
assert (r/'bounded-probe-binary.json').exists()
files={p.name:p for p in r.iterdir() if p.is_file() and p.suffix in ('.json','.xml','.py','.hip')}
for p in (r/'logs').iterdir():
 if p.is_file():files[str(p.relative_to(r))]=p
files['cuda/CMakeCache.txt']=r/'cuda/CMakeCache.txt'
for test in json.loads((r/'cuda-selection.json').read_text())['tests']:
 cmd=test.get('command',[])
 if '--report' in cmd:
  p=Path(cmd[cmd.index('--report')+1]);assert p.is_relative_to(r/'cuda') and p.exists()
  files[str(p.relative_to(r))]=p
for name in ['LastTest.log','LastTestsFailed.log']:
 p=r/'cuda/Testing/Temporary'/name
 if p.exists():files['cuda/'+name]=p
files['oracle-source.json']=Path('/var/tmp/keyhunt-c23-ethereum-oracle/oracle-source.json')
with tarfile.open(r/'audit-transfer.tar.gz','w:gz') as archive:
 for name,p in sorted(files.items()):archive.add(p,arcname=name,recursive=False)
print('files',len(files),'bytes',(r/'audit-transfer.tar.gz').stat().st_size)
