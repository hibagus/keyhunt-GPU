from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
r=Path(__file__).resolve().parent
status=r/'cuda-tests.json'
while not status.exists():time.sleep(5)
if json.loads(status.read_text())['exit_code']:raise SystemExit('correctness suite failed; benchmark deferred')
env=dict(os.environ,TMPDIR='/var/tmp',KEYHUNT_KECCAK_ORACLE_ROOT='/var/tmp/keyhunt-c23-ethereum-oracle')
runs=[]
def run(name,cmd,output):
    start=time.monotonic();began=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (r/output).open('w') as f,(r/'logs'/f'{name}.stderr').open('w') as err:
        result=subprocess.run(cmd,stdout=f,stderr=err,env=env)
    runs.append(dict(name=name,command=cmd,started_utc=began,seconds=time.monotonic()-start,exit_code=result.returncode))
    (r/'post-cuda.json').write_text(json.dumps(runs,indent=2)+'\n')
    print(name,result.returncode,flush=True)
    if result.returncode:raise SystemExit(result.returncode)
run('cuda-load-before',['nvidia-smi','--query-gpu=index,uuid,name,driver_version,pstate,utilization.gpu,memory.used,clocks.current.sm,power.draw','--format=csv'],'logs/cuda-load-before.csv')
run('minikey-cuda',[str(r/'minikey_probe'),'0'],'minikey-cuda.json')
run('glv-cuda',['python3',str(r/'source/tools/profile_glv.py'),'--benchmark',str(r/'cuda/cuda_glv_benchmark'),'--keyhunt',str(r/'cuda/keyhunt'),'--backend','cuda','--device','0','--output',str(r/'glv-cuda.json')],'logs/glv-cuda.log')
run('memcheck-experiment',['/usr/local/cuda-13.3/bin/compute-sanitizer','--tool','memcheck','--error-exitcode','97',str(r/'minikey_probe'),'0','smoke'],'logs/memcheck-experiment.log')
run('memcheck-production',['/usr/local/cuda-13.3/bin/compute-sanitizer','--tool','memcheck','--error-exitcode','97',str(r/'cuda/cuda_minikeys_executor_test')],'logs/memcheck-production.log')
run('cuda-load-after',['nvidia-smi','--query-gpu=index,uuid,name,driver_version,pstate,utilization.gpu,memory.used,clocks.current.sm,power.draw','--format=csv'],'logs/cuda-load-after.csv')
(r/'probe-binary.json').write_text(json.dumps(dict(sha256=hashlib.sha256((r/'minikey_probe').read_bytes()).hexdigest(),source_sha256=hashlib.sha256((r/'minikey_probe.hip').read_bytes()).hexdigest()),indent=2)+'\n')
