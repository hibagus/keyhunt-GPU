from pathlib import Path
import datetime,hashlib,json,platform,subprocess,sys
r=Path(__file__).resolve().parent;names=sys.argv[1:];report=dict(captured_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),hostname=platform.node(),platform=platform.platform(),root=str(r),source=subprocess.check_output(['git','-C',str(r/'source'),'rev-parse','HEAD'],text=True).strip(),source_status=subprocess.check_output(['git','-C',str(r/'source'),'status','--porcelain'],text=True),binaries={},settings={})
for name in names:
 b=r/name;report['settings'][name]=[line for line in (b/'CMakeCache.txt').read_text().splitlines() if line.startswith(('CMAKE_BUILD_TYPE:','CMAKE_CXX_COMPILER:','CMAKE_HIP_COMPILER:','CMAKE_CUDA_COMPILER:','CMAKE_HIP_ARCHITECTURES:','CMAKE_CUDA_ARCHITECTURES:','KEYHUNT_','CMAKE_CXX_FLAGS:','CMAKE_HIP_FLAGS:','CMAKE_CUDA_FLAGS:'))]
 for path in sorted(b.iterdir()):
  if path.is_file() and path.stat().st_mode&0o111:report['binaries'][str(path.relative_to(r))]=dict(bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
for path in [r/'minikey_probe',r/'minikey_probe.hip',r/'bounded_minikey_probe',r/'bounded_minikey_probe.hip']:
 report['binaries'][path.name]=dict(bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
(r/'capture.json').write_text(json.dumps(report,indent=2)+'\n');print(report['hostname'],len(report['binaries']),repr(report['source_status']))
