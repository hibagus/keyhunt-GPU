from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
r=Path(__file__).resolve().parent
prior=json.loads((r/'post-cuda.json').read_text())
assert len(prior)==5 and all(v['exit_code']==0 for v in prior[:4]) and prior[-1]['exit_code']==97
log=(r/'logs/memcheck-production.log').read_text()
assert 'ERROR SUMMARY: 6 errors' in log and log.count('CUDA API Error: Invalid device number -1')==2 and log.count('Program hit cudaErrorInvalidDevice')==4
env=dict(os.environ,TMPDIR='/var/tmp',KEYHUNT_KECCAK_ORACLE_ROOT='/var/tmp/keyhunt-c23-ethereum-oracle')
runs=[]
def run(name,cmd,output):
    start=time.monotonic();began=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (r/output).open('w') as f,(r/'logs'/f'{name}.stderr').open('w') as err:
        result=subprocess.run(cmd,stdout=f,stderr=err,env=env)
    runs.append(dict(name=name,command=cmd,started_utc=began,seconds=time.monotonic()-start,exit_code=result.returncode))
    (r/'post-bounded-cuda.json').write_text(json.dumps(runs,indent=2)+'\n')
    print(name,result.returncode,flush=True)
    if result.returncode:raise SystemExit(result.returncode)
run('memcheck-production-api-suppressed',['/usr/local/cuda-13.3/bin/compute-sanitizer','--tool','memcheck','--report-api-errors','no','--error-exitcode','97',str(r/'cuda/cuda_minikeys_executor_test')],'logs/memcheck-production-api-suppressed.log')
run('bounded-minikey-cuda',[str(r/'bounded_minikey_probe'),'0'],'bounded-minikey-cuda.json')
run('memcheck-bounded-experiment',['/usr/local/cuda-13.3/bin/compute-sanitizer','--tool','memcheck','--error-exitcode','97',str(r/'bounded_minikey_probe'),'0','smoke'],'logs/memcheck-bounded-experiment.log')
run('bounded-cuda-resources',['/usr/local/cuda-13.3/bin/cuobjdump','--dump-resource-usage',str(r/'bounded_minikey_probe')],'logs/bounded-cuda-resources.log')
run('cuda-load-after',['nvidia-smi','--query-gpu=index,uuid,name,driver_version,pstate,utilization.gpu,memory.used,clocks.current.sm,power.draw','--format=csv'],'logs/cuda-load-after.csv')
(r/'bounded-probe-binary.json').write_text(json.dumps(dict(sha256=hashlib.sha256((r/'bounded_minikey_probe').read_bytes()).hexdigest(),source_sha256=hashlib.sha256((r/'bounded_minikey_probe.hip').read_bytes()).hexdigest()),indent=2)+'\n')
