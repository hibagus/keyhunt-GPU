import pathlib,subprocess,json,sys
r=pathlib.Path(__file__).resolve().parent;backend=sys.argv[1];s=r/'source';b=r/backend;stem=sys.argv[2] if len(sys.argv)>2 else 'minikey_probe'
include=[str(s/x) for x in ['include','third_party','kernels','kernels/search','src/backend/gpu']]
include+=['/tmp/keyhunt-c15-deps/root/usr/include' if backend=='hip' else '/tmp/keyhunt-c20-deps/root/usr/include']
args=(['/opt/rocm/core-10.0/lib/llvm/bin/clang++','-x','hip','--offload-arch=gfx942'] if backend=='hip' else ['/usr/local/cuda-13.3/bin/nvcc','-x','cu','-arch=sm_90'])+['-O3','-DNDEBUG','-std=c++17']+['-I'+x for x in include]+['-c',str(r/(stem+'.hip')),'-o',str(r/(stem+'.o'))]
link=['c++',str(r/(stem+'.o')),'-o',str(r/stem)]+[str(b/x) for x in ['libkeyhunt_core.a','libkeyhunt_cpu_crypto.a','libkeyhunt_common.a','libkeyhunt_ranges.a','libkeyhunt_sha256.a']]+['-lm','-pthread']
if backend=='hip':link+=['-L/opt/rocm/core-10.0/lib','-Wl,-rpath,/opt/rocm/core-10.0/lib','-lamdhip64']
else:link+=['-L/usr/local/cuda-13.3/lib64','-Wl,-rpath,/usr/local/cuda-13.3/lib64','-lcudart']
(r/(stem+'-build-commands.json')).write_text(json.dumps([args,link],indent=2)+'\n')
with (r/'logs'/(stem+'-build.log')).open('w') as f:
 for cmd in [args,link]:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
print('built',backend)
