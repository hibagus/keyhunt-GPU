import subprocess,pathlib,json,time
r=pathlib.Path(__file__).resolve().parent
common=['-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH=/tmp/keyhunt-c15-deps/root/usr','-DKEYHUNT_ENABLE_COORDINATOR=ON','-DKEYHUNT_ENABLE_HTTPS_WORKER=ON','-DKEYHUNT_TEST_APACHE_ROOT=/tmp/keyhunt-c15-deps/root','-DSQLite3_INCLUDE_DIR=/opt/rocm/core-10.0/lib/rocm_sysdeps/include','-DSQLite3_LIBRARY=/opt/rocm/core-10.0/lib/rocm_sysdeps/lib/librocm_sysdeps_sqlite3.so','-DCURL_INCLUDE_DIR=/tmp/keyhunt-c15-deps/root/usr/include/x86_64-linux-gnu','-DCURL_LIBRARY=/tmp/keyhunt-c15-deps/root/usr/lib/x86_64-linux-gnu/libcurl.so']
results=[]
for name,extra in [('cpu',[]),('hip',['-DKEYHUNT_ENABLE_HIP=ON','-DCMAKE_HIP_COMPILER=/opt/rocm/core-10.0/lib/llvm/bin/clang++','-DCMAKE_HIP_ARCHITECTURES=gfx942'])]:
 for stage,args in [('configure',['cmake','-S',str(r/'source'),'-B',str(r/name),*common,*extra]),('build',['cmake','--build',str(r/name),'--parallel','12'])]:
  start=time.monotonic()
  with (r/'logs'/f'{name}-{stage}.log').open('w') as f: rc=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT).returncode
  results.append(dict(build=name,stage=stage,command=args,exit_code=rc,seconds=time.monotonic()-start)); print(name,stage,rc,flush=True)
  (r/'builds.json').write_text(json.dumps(results,indent=2)+'\n')
  if rc: raise SystemExit(rc)
