"""Eight independent CLI exporters racing against one exclusive destination."""
import pathlib,subprocess,json,concurrent.futures,tempfile,hashlib,argparse
p=argparse.ArgumentParser();p.add_argument('--worker',required=True);p.add_argument('--output',type=pathlib.Path,required=True);a=p.parse_args();report={}
with tempfile.TemporaryDirectory(prefix='keyhunt-c22-publication-',dir='/var/tmp') as tmp:
 t=pathlib.Path(tmp);state=t/'state';config=t/'config.json';config.write_text(json.dumps(dict(transport='file',endpoint='https://test.invalid',jobs=[dict(project='00000000-0000-0000-0000-000000000001',job='0'*64,devices=['0'],spares=1,policy='sequential')])));config.chmod(0o600)
 subprocess.run([a.worker,'configure','--state-dir',str(state),'--config',str(config)],capture_output=True,check=True)
 def export(name):
  cmd=[a.worker,'file-export','--state-dir',str(state),'--output',str(t/name)];x=subprocess.run(cmd,capture_output=True,text=True,timeout=30);return dict(command=cmd,exit_code=x.returncode,stdout=x.stdout,stderr=x.stderr)
 with concurrent.futures.ThreadPoolExecutor(8) as pool:
  report['same_destination']=list(pool.map(export,['same.json']*8))
  report['separate_destinations']=list(pool.map(export,[f'copy-{i}.json' for i in range(8)]))
 assert sum(x['exit_code']==0 for x in report['same_destination'])==1
 assert all(x['exit_code']==0 for x in report['separate_destinations'])
 original=(t/'same.json').read_bytes();assert all((t/f'copy-{i}.json').read_bytes()==original for i in range(8))
 assert not list(t.glob('.offline-*'))
 report['sha256']=hashlib.sha256(original).hexdigest();report['state']=json.loads(subprocess.check_output([a.worker,'status','--state-dir',str(state)]));report['passed']=True
 a.output.write_text(json.dumps(report,indent=2)+'\n')
print('PASS concurrent exclusive publication')
