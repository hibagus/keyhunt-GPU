#include "fixture.h"
#include "keyhunt/coordinator/worker.h"
#include <iostream>
using namespace cfixture;
int main(int argc,char** argv){try{
 require(argc==2,"state root required");std::string root=argv[1];int64_t now=1800000000;
 Repository repo(root+"/server",[&]{return now;});Worker worker(root+"/worker",[&]{return now;});
 core::XPointVerifier verifier;auto targets=x_targets(verifier,{1,10});
 auto leaf=pem(1,now-60,now+90*86400);auto cert=certificate(leaf);
 auto client=repo.admin({{"operation","bootstrap"},{"name","v6 migration fixture"},{"certificate",leaf}});
 std::string project=repo.admin({{"operation","project-create"},{"name","v6 active work"},{"owner",client["client"]}})["project"];
 auto job=repo.request(cert,"POST","/api/v1/projects/"+project+"/jobs",job_input(targets));
 worker.configure({{"endpoint","https://test.invalid"},{"ca","/fixture/ca"},{"certificate","/fixture/cert"},{"key","/fixture/key"},
 {"jobs",{{{"project",project},{"job",job["job"]},{"devices",{"0"}},{"spares",1},{"policy","sequential"}}}}});
 worker.synchronize([&](const Json& body){return Json{{"ok",true},{"server_time",now},{"value",repo.request(cert,"POST","/api/v1/sync",body)}};},true);
 auto grant=*worker.next("0");CheckpointOptions options;options.xpoint_steps=1;options.checkpoint_seconds=0;
 auto result=CheckpointRun::xpoint(worker.journal(),grant,targets,verifier,[&](const auto& batch){return execute(batch,targets,verifier,1024);},options);
 require(result.complete,"v6 fixture did not complete");
 rejects([&]{worker.synchronize([](const Json&)->Json{throw std::runtime_error("transport unavailable after snapshot saved");},true);});
 auto status=worker.status();require(status["pending_request"]==true&&status["outbox_bytes"].get<int64_t>()>0,"missing v6 pending work");
 worker.journal().check();repo.admin({{"operation","check"}});std::cout<<status.dump(2)<<'\n';
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
