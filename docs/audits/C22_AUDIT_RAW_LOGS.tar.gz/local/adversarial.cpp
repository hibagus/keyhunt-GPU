// Reuse only fixture construction; production libraries remain unmodified.
#define main c22_original_fixture_main
#include "offline.cpp"
#undef main
int main(){try{
    Json cases=Json::array();
    {
        Scenario s;auto request=s.worker.export_request();auto response=s.relay(request);
        auto invalid=response;invalid["body"]["value"]["grants"][3]["grant"]["end_exclusive"]=UInt256(1000).hex();
        rejects([&]{s.worker.import_response(invalid);});
        require(s.worker.status()["queues"].empty(),"late invalid grant leaked earlier imports");
        require(s.worker.export_request()==request,"failed import changed pending exchange");
        require(s.worker.import_response(response),"corrected import did not apply");s.audit();
        cases.push_back("fourth-grant rejection rolls back all previous imports");
    }
    {
        Scenario s;const auto request=s.worker.export_request();const auto old=s.relay(request);
        s.repo.request(s.cert,"POST",s.path+"/pause",{{"paused",true}});
        const auto paused=s.relay(request);require(paused["body"]["value"]==old["body"]["value"],"fixture did not use cached receipt");
        require(paused["body"]["controls"][0]["paused"]==true,"cached response lost current pause");
        s.worker.import_response(paused);require(!s.worker.next("0"),"cached receipt bypassed current pause");
        s.repo.request(s.cert,"POST",s.path+"/pause",{{"paused",false}});s.exchange();require(bool(s.worker.next("0")),"reviewed resume failed");s.audit();
        cases.push_back("cached receipt refreshes pause controls and later exchange resumes");
    }
    {
        Scenario s;s.exchange();s.execute_one(*s.worker.next("0"));
        const auto request=s.worker.export_request();const auto before=s.worker.status()["outbox_bytes"];
        require(before.get<int64_t>()>0,"no queued checkpoint fixture");
        const auto denial=offline_response(request,403,{{"error","current role refused"}});
        s.worker.import_response(denial);require(!s.worker.next("1"),"denial left peer runnable");
        require(s.worker.status()["outbox_bytes"]==before,"denial discarded unsent checkpoints");
        require(!s.worker.import_response(denial),"duplicate denial reapplied");
        auto next=s.worker.export_request();require(next["body"]==request["body"]&&next["transfer"]!=request["transfer"],"denial retry lost immutable page");
        s.worker.import_response(s.relay(next));require(s.worker.status()["outbox_bytes"]==0,"reviewed retry did not reconcile retained page");s.audit();
        cases.push_back("denial preserves pending results and immutable retry reconciles them");
    }
    {
        Scenario s;const auto request=s.worker.export_request();s.relay(request);
        s.repo.admin({{"operation","membership-set"},{"project",s.project},{"client",s.client["client"]},{"role","reader"}});
        denied(403,[&]{s.relay(request);});
        cases.push_back("cached receipt cannot bypass current membership downgrade");
    }
    {
        Scenario s;const auto request=s.worker.export_request();const auto response=s.relay(request);
        s.monotonic+=2592001;s.now+=2592001;
        require(s.worker.import_response(response),"elapsed response could not be reconciled");
        require(!s.worker.next("0")&&!s.worker.next("1"),"late import restarted expired lease");
        require(!s.worker.import_response(response),"late duplicate not idempotent");s.audit();
        cases.push_back("delivery after entire lease imports receipt without runnable grants");
    }
    std::cout<<Json({{"passed",true},{"cases",cases}}).dump(2)<<'\n';
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
