import pathlib,subprocess,sqlite3,json,hashlib,tempfile
r=pathlib.Path(__file__).resolve().parent;old=pathlib.Path('/tmp/keyhunt-c21-audit-i_1xummg');s=old/'source';b=old/'hip'
cmd=['c++','-O2','-std=c++17',str(r/'migration_v6.cpp'),'-o',str(r/'migration_v6')]
for p in ['tests/coordinator','src/storage','src/coordinator','include','third_party']:cmd+=['-I'+str(s/p)]
cmd+=['-isystem','/opt/rocm/core-10.0/lib/rocm_sysdeps/include','-isystem','/tmp/keyhunt-c15-deps/root/usr/include','-Wl,-rpath,/opt/rocm/core-10.0/lib/rocm_sysdeps/lib']
cmd+=[str(b/x) for x in ['libkeyhunt_coordination.a','libkeyhunt_storage.a','libkeyhunt_core.a','libkeyhunt_cpu_crypto.a','libkeyhunt_common.a']]
cmd+=['-lm',str(b/'libkeyhunt_ranges.a'),'/opt/rocm/core-10.0/lib/rocm_sysdeps/lib/librocm_sysdeps_sqlite3.so','/usr/lib/x86_64-linux-gnu/libcrypto.so']
with (r/'logs/migration-build.log').open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
report=dict(old_source=subprocess.check_output(['git','-C',str(s),'rev-parse','HEAD'],text=True).strip(),compile=cmd,commands=[])
def run(args):
 x=subprocess.run(list(map(str,args)),capture_output=True,text=True,check=True);report['commands'].append(dict(command=list(map(str,args)),stdout=x.stdout,stderr=x.stderr));return json.loads(x.stdout)
def snapshot(path):
 with sqlite3.connect(f'file:{path}?mode=ro',uri=True) as db:
  version=db.execute('pragma user_version').fetchone()[0];tables={}
  for name, in db.execute("select name from sqlite_master where type='table' and name not like 'sqlite_%' order by name"):
   rows=db.execute('select * from "'+name.replace('"','""')+'"').fetchall();encoded=sorted(repr(x) for x in rows);tables[name]=dict(rows=len(rows),sha256=hashlib.sha256(json.dumps(encoded).encode()).hexdigest())
  return dict(version=version,tables=tables,metadata={k:v.hex() for k,v in db.execute('select key,value from metadata')})
with tempfile.TemporaryDirectory(prefix='keyhunt-c22-v6-',dir='/var/tmp') as t:
 root=pathlib.Path(t);report['before_status']=run([r/'migration_v6',root]);report['before']={n:snapshot(root/n/'progress.sqlite') for n in ['worker','server']}
 for n in ['worker','server']:run([r/'cpu/keyhunt','state','check','--state-dir',root/n])
 report['after']={n:snapshot(root/n/'progress.sqlite') for n in ['worker','server']}
 for n in ['worker','server']:
  before,after=report['before'][n],report['after'][n];assert before['version']==6 and after['version']==7
  assert set(after['tables'])-set(before['tables'])=={'worker_file_transfers'}
  for name,value in before['tables'].items():
   if name!='migrations':assert after['tables'][name]==value,(n,name)
  assert after['tables']['migrations']['rows']==before['tables']['migrations']['rows']+1
  backup=list((root/n).glob('pre-v7-*'));assert len(backup)==1
  sealed=snapshot(backup[0]/'progress.sqlite');assert sealed['version']==6
  assert set(sealed['tables'])==set(before['tables'])
  assert all(sealed['tables'][k]==v for k,v in before['tables'].items() if k!='metadata')
  assert set(sealed['metadata'])==set(before['metadata'])
  assert {k for k,v in before['metadata'].items() if sealed['metadata'][k]!=v}=={'epoch','quarantine'}
  assert sealed['metadata']['quarantine']=='01' and len(sealed['metadata']['epoch'])==32
  report.setdefault('sealed_backups',{})[n]=sealed
 report['after_status']=run([r/'cpu/keyhunt-worker','status','--state-dir',root/'worker'])
 for key in ['instance','client','pending_request','outbox_bytes','queues']:assert report['after_status'][key]==report['before_status'][key],key
 assert report['after_status']['transport']=='https'
report['passed']=True;(r/'migration-v6.json').write_text(json.dumps(report,indent=2)+'\n');print('PASS populated C21 v6 worker/server migration, pending request/results and sealed backups')
