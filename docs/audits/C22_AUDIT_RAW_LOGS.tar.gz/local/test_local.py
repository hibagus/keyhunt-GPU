import pathlib,subprocess,time,json,concurrent.futures
r=pathlib.Path(__file__).resolve().parent

def run(name,extra):
 cmd=['ctest','--test-dir',str(r/name),'--output-on-failure','--parallel','8','--output-junit',str(r/f'{name}-tests.xml'),*extra]; start=time.monotonic()
 with (r/'logs'/f'{name}-tests.log').open('w') as f: rc=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT).returncode
 result=dict(build=name,command=cmd,exit_code=rc,seconds=time.monotonic()-start)
 (r/f'{name}-tests.json').write_text(json.dumps(result,indent=2)+'\n');print(name,rc,flush=True);return rc
with concurrent.futures.ThreadPoolExecutor(2) as pool:
 codes=list(pool.map(lambda x:run(*x),[('cpu',[]),('hip',['-R','^(coordinator_|storage_|checkpoint_)'])]))
raise SystemExit(max(codes))
