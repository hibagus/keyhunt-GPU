"""Assemble public-fixture C22 acceptance evidence after all gates finish."""
from pathlib import Path
import hashlib, io, json, re, subprocess, tarfile
from datetime import datetime, timezone

repo=Path('/home/bagus/keyhunt-GPU')
evidence=Path('/var/tmp/keyhunt-c22-evidence')
base=repo/'docs/baselines'
def digest(data): return hashlib.sha256(data).hexdigest()
def write_json(path, value): path.write_text(json.dumps(value,indent=2)+'\n')
checks={}
logs={}
selections={
 'plain_cpu_release':('cpu-tests',34),
 'coordinator_cpu_release':('release-tests',51),
 'file_status_followup':('file-status-tests',4),
 'clock_release_followup':('clock-tests',2),
 'debug_final':('debug-final-tests',6),
 'asan_ubsan_final':('sanitizers-final-tests',5),
 'hip_regressions':('hip-regressions',29),
 'hip_clock_followup':('hip-clock-tests',2),
}
for name,(stem,count) in selections.items():
 p=Path('/var/tmp')/('keyhunt-c22-'+stem+'.log'); raw=p.read_bytes()
 assert f'100% tests passed, 0 tests failed out of {count}' in raw.decode(),name
 checks[name]=dict(passed=count,failed=0,log=p.name)
 logs[p.name]=raw
for stem in ['cpu-configure','cpu-build','release-build','file-status-build','clock-build',
             'debug-configure','debug-final-build','sanitizers-configure','sanitizers-final-build',
             'hip-configure','hip-build','hip-clock-build','documentation']:
 p=Path('/var/tmp')/('keyhunt-c22-'+stem+'.log');logs[p.name]=p.read_bytes()
# Only explicitly selected files are archived, never whole state/config folders.
for backend in ['hip','cuda']:
 for p in sorted((evidence/backend).iterdir()):
  if p.is_file(): logs[backend+'/'+p.name]=p.read_bytes()
for stem,count in [('cpu-tests',20),('clock-tests',2),('fleet-retry',1)]:
 raw=logs['cuda/'+stem+'.log'].decode()
 assert f'100% tests passed, 0 tests failed out of {count}' in raw,stem
 checks['cuda_'+stem]=dict(passed=count,failed=0,log='cuda/'+stem+'.log')
assert '80% tests passed, 1 tests failed out of 5' in logs['cuda/hardware-tests.log'].decode()
assert 'not a git repository' in logs['cuda/hardware-tests.log'].decode()
checks['cuda_hardware']=dict(passed=5,failed=0,initial_log='cuda/hardware-tests.log',
 initial_result='4/5 passed; fleet metadata required Git history missing from the extracted archive',
 resolution='Installed the matching Git history without changing source files; the failed fleet gate then passed',
 followup_log='cuda/fleet-retry.log')
reports={
 'cpu':json.loads((repo/'build/coordinator-release/coordinator-offline-cli.json').read_text()),
 'hip':json.loads((repo/'build/hip-release/coordinator-offline-cli.json').read_text()),
 'cuda':json.loads((evidence/'cuda/coordinator-offline-cli.json').read_text())}
for backend, report in reports.items():
 assert report['passed'] and report['hardware']==(backend!='cpu')
 assert [c['mode'] for c in report['cases']]==['xpoint','bsgs']
 for case in report['cases']:
  assert case['reserved_blocks']==2
  if backend!='cpu':
   assert case['final_status']['outbox_bytes']==0
   assert len(case['server_results'])==1 and int(case['server_results'][0]['scalar'],16)==1
   assert len(case['blocks'])==2
write_json(base/'C22_OFFLINE.json',reports)
logs['keyhunt-c22-record.py']=Path(__file__).read_bytes()
logs['keyhunt-c22-remote-validation.py']=Path('/var/tmp/keyhunt-c22-remote-validation.py').read_bytes()
for name, raw in logs.items():
 assert not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',raw),name
with tarfile.open(base/'C22_LOGS.tar.gz','w:gz') as archive:
 for name,raw in logs.items():
  info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;archive.addfile(info,io.BytesIO(raw))
source_commit=subprocess.check_output(['git','rev-parse','403fd61'],cwd=repo,text=True).strip()
changed=subprocess.check_output(['git','diff','--name-only','f7242a0',source_commit],cwd=repo,text=True).splitlines()
source_paths=[p for p in changed if not p.startswith('docs/') and p!='README.md']
for path in source_paths:
 assert (repo/path).read_bytes()==subprocess.check_output(['git','show',source_commit+':'+path],cwd=repo),path
publications=['README.md','docs/C22_VALIDATION.md','docs/OFFLINE_ASSIGNMENTS.md',
 'docs/COORDINATOR.md','docs/STORAGE.md','docs/CHECKPOINTS.md','docs/OPERATIONS.md',
 'docs/MULTI_GPU.md','docs/MODES.md','docs/GPU_QUICKSTART.md','docs/GPU_REDESIGN_PLAN.md','docs/IMPLEMENTATION_STATUS.md']
manifest=dict(milestone='C22',recorded_utc=datetime.now(timezone.utc).isoformat(),passed=True,
 source_commit=source_commit,production_last_changed_commit='cc9da27',schema_version=7,
 scope='Trusted courier file transport over existing mTLS machine sync; localhost transport and disconnected HIP/CUDA execution',
 checks=checks,source_sha256={p:digest((repo/p).read_bytes()) for p in source_paths},
 publication_sha256={p:digest((repo/p).read_bytes()) for p in publications},
 binary_sha256={k:v['binaries'] for k,v in reports.items()},
 log_members={name:digest(raw) for name,raw in logs.items()},
 artifacts={p.name:dict(sha256=digest(p.read_bytes()),bytes=p.stat().st_size) for p in [base/'C22_OFFLINE.json',base/'C22_LOGS.tar.gz']},
 limits=['Trusted-channel checksum pinning, no new file signing/encryption authority',
 'Coordinator cannot interrupt already disconnected GPUs; stopped-owner recovery remains required',
 'Localhost mTLS on each host; physical cross-host file delivery and public ingress unvalidated',
 'Two tiny blocks per mode on one selected GPU per backend; no performance or endurance claim',
 'No kernel changes; prior broad arithmetic/search/scale evidence retained',
 'No hosted CI run; MIG/QPX search and genuine driver-hang recovery unvalidated',
 'Transfer history retained outside bounded outbox; no automatic history archival'])
manifest['published_migrations_unchanged']={}
for version in range(1,7):
 path=f'src/storage/schema_v{version}.sql'
 raw=(repo/path).read_bytes()
 assert raw==subprocess.check_output(['git','show','f7242a0:'+path],cwd=repo)
 manifest['published_migrations_unchanged'][path]=digest(raw)
manifest['gpu_backend_changes']=subprocess.check_output(['git','diff','--name-only','f7242a0',source_commit,'--','src/backend','include/keyhunt/backend'],cwd=repo,text=True).splitlines()
assert not manifest['gpu_backend_changes']
write_json(base/'C22_VALIDATION.json',manifest)
print('Recorded',len(logs),'log/report artifacts and',len(source_paths),'source/test hashes')
