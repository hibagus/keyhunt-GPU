"""Run C22 GPU gates after the separate frozen C21 audit releases this host."""
from pathlib import Path
import hashlib,json,os,platform,subprocess,time
root=Path('/var/tmp/keyhunt-c22-dc31a34')
audit=Path('/var/tmp/keyhunt-c21-audit-gv7rtq35')
# Wait for the audit's final two GPU artifacts, avoiding its timing samples.
last=None
while True:
 ready=True
 for name in ['CUDA_LIFECYCLE.json','CUDA_OPERATIONS.json']:
  p=audit/name
  try: ready=ready and json.loads(p.read_text())['passed']
  except (OSError,ValueError,KeyError): ready=False
 if ready: break
 state=','.join(p.name for p in audit.glob('CUDA_*.json')) or 'full test suite'
 if state!=last:
  print('Waiting for independent C21 audit:',state,flush=True);last=state
 time.sleep(5)
print('C21 GPU work complete; starting five C22 hardware gates',flush=True)
words=['ctest','--test-dir',str(root/'build'),'--output-on-failure','-R',
       '^(checkpoint_cli|checkpoint_pause_cuda|coordinator_https_worker|coordinator_fleet|coordinator_offline_cli)$']
with (root/'hardware-tests.log').open('w') as log:
 result=subprocess.run(words,env=dict(os.environ,TMPDIR='/var/tmp'),stdout=log,stderr=subprocess.STDOUT)
print((root/'hardware-tests.log').read_text(),flush=True)
if result.returncode: raise SystemExit(result.returncode)
metadata=dict(host=platform.node(),system=platform.platform(),commands={},source_snapshot='403fd61')
for name,words in {'nvcc':['/usr/local/cuda/bin/nvcc','--version'],
                   'gcc':['g++','--version'],'cmake':['cmake','--version'],
                   'nvidia':['nvidia-smi','--query-gpu=index,name,uuid,driver_version,mig.mode.current','--format=csv,noheader']}.items():
 r=subprocess.run(words,capture_output=True,text=True)
 metadata['commands'][name]=dict(exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr)
metadata['inventory']=json.loads(subprocess.check_output([str(root/'build/keyhunt'),'devices','--backend','cuda'],text=True))
metadata['binaries']={p:hashlib.sha256((root/'build'/p).read_bytes()).hexdigest() for p in ['keyhunt','keyhunt-worker','keyhunt-coordinator']}
(root/'environment.json').write_text(json.dumps(metadata,indent=2)+'\n')
print('C22 H200 hardware validation complete',flush=True)
