import hashlib,json,platform,subprocess,sys
from pathlib import Path
repo=Path(sys.argv[1]);builds=[Path(x) for x in sys.argv[2:]]
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
result=dict(source_commit=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),
            platform=platform.platform(),binaries={},build_configuration={})
for build in builds:
 result['binaries'][str(build)]={name:digest(build/name) for name in ('keyhunt','keyhunt-worker','keyhunt-coordinator')}
 keys=('CMAKE_BUILD_TYPE','CMAKE_CXX_COMPILER','CMAKE_HIP_COMPILER','CMAKE_CUDA_COMPILER','CMAKE_CUDA_ARCHITECTURES','CMAKE_HIP_ARCHITECTURES',
       'KEYHUNT_ENABLE_CUDA','KEYHUNT_ENABLE_HIP','KEYHUNT_ENABLE_COORDINATOR','KEYHUNT_ENABLE_HTTPS_WORKER','KEYHUNT_ENABLE_SANITIZERS',
       'KEYHUNT_ENABLE_LTO','KEYHUNT_GFX942_CARRY','KEYHUNT_CUDA_PTX','KEYHUNT_CUDA_PTX_ARITHMETIC')
 result['build_configuration'][str(build)]={line.split(':')[0]:line.split('=',1)[1] for line in (build/'CMakeCache.txt').read_text().splitlines()
                                           if ':' in line and '=' in line and line.split(':')[0] in keys}
print(json.dumps(result,indent=2))
