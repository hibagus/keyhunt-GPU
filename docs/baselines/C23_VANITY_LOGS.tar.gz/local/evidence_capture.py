from pathlib import Path
import datetime,hashlib,json,subprocess,tarfile
repo=Path.cwd();raw=Path('/var/tmp/keyhunt-c23-vanity-evidence');out=repo/'docs/baselines'
def read(path):return json.loads(path.read_text())
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(name,value):
 path=out/name;path.write_text(json.dumps(value,indent=2)+'\n');return path
reports={}
for backend in ('hip','cuda'):
 reports[backend]={
  'base58_vectors':read(raw/backend/f'{backend}-base58-oracle.json'),
  'stepped':read(raw/backend/'vanity-cli-results.json'),
  'direct':read(raw/backend/'vanity-cli-direct-results.json'),
  'checkpoints':read(raw/backend/'checkpoint-vanity-cli.json'),
  'shared_checkpoints':read(raw/backend/'checkpoint-cli-results.json'),
  'pause':read(raw/backend/f'checkpoint-vanity-pause-{backend}.json'),
  'offline':read(raw/backend/'coordinator-offline-cli.json'),
  'examples':read(raw/backend/f'keyhunt-vanity-examples-{backend}.json')}
 assert reports[backend]['base58_vectors']['cases']==345 and reports[backend]['base58_vectors']['passed']
 for kernel in ('direct','stepped'):
  report=reports[backend][kernel]
  assert report['passed'] and len(report['cases'])==50 and report['rejections']==31
  assert len(report['inventory']['devices'])==8
  assert all(c['summary']['complete'] for c in report['cases'])
 for kind in ('checkpoints','shared_checkpoints','pause','offline','examples'):assert reports[backend][kind]['passed']
 assert len(reports[backend]['checkpoints']['cases'])==9
 assert [c['mode'] for c in reports[backend]['offline']['cases']]==['xpoint','bsgs','hash160','ethereum','vanity']
 vanity=reports[backend]['offline']['cases'][-1]
 assert len(vanity['local_results']['results'])==len(vanity['server_results'])==2
 assert all(len(r['target_bytes'])==72 and int(r['scalar'],16)==1 for r in vanity['local_results']['results'])
 assert len(vanity['blocks'])==2
 finishes=[e for e in vanity['events'] if e.get('type')=='grant-finish']
 assert len(finishes)==2 and all(e['executor_setups']==1 and e['mode']=='vanity' for e in finishes)
 assert finishes[0]['cold'] and not finishes[1]['cold']
 assert vanity['final_status']['outbox_bytes']==0
 assert reports[backend]['checkpoints']['cases'][-1]['name']=='kill-and-restart'
 assert reports[backend]['pause']['changed_inventory_tested']
 assert [c['mode'] for c in reports[backend]['pause']['cases']]==['vanity']
artifacts=[]
for label,keys in [('ALGORITHMS',('base58_vectors','direct','stepped')),('RECOVERY',('checkpoints','shared_checkpoints','pause')),('OFFLINE',('offline',))]:
 artifacts.append(save(f'C23_VANITY_{label}.json',{b:{k:reports[b][k] for k in keys} for b in reports}))
examples={b:reports[b]['examples'] for b in reports};examples['cpu']=read(raw/'local/keyhunt-vanity-examples-cpu.json')
assert all(r['passed'] for r in examples.values())
assert all(r['document_sha256']==digest(repo/'docs/GPU_QUICKSTART.md') for r in examples.values())
artifacts.append(save('C23_VANITY_EXAMPLES.json',examples))
specs=[('cpu_release','local/keyhunt-vanity-cpu-tests.log',36,'9620ee8'),
 ('asan_ubsan','local/keyhunt-vanity-sanitizers-tests.log',23,'9620ee8'),
 ('hip_algorithms','hip/algorithms.log',7,'a92ec59'),
 ('hip_recovery_regression','hip/keyhunt-vanity-hip-recovery.log',13,'9620ee8'),
 ('cuda_algorithms','cuda/keyhunt-vanity-cuda-algorithms.log',7,'a92ec59'),
 ('cuda_recovery_regression','cuda/keyhunt-vanity-cuda-recovery.log',14,'4050664'),
 ('cpu_coordinator_overlap','local/keyhunt-vanity-overlap-cpu.log',1,'4050664'),
 ('sanitizer_coordinator_overlap','local/keyhunt-vanity-overlap-sanitizers.log',1,'4050664'),
 ('hip_coordinator_overlap','hip/keyhunt-vanity-overlap-hip.log',1,'4050664')]
checks={}
for name,log,count,commit in specs:
 text=(raw/log).read_text()
 assert f'100% tests passed, 0 tests failed out of {count}' in text,(name,text[-1500:])
 checks[name]={'passed':count,'failed':0,'log':log,'source_phase':commit}
# This archive deliberately takes only our selected logs/reports, never fixture
# directories, credentials, SQLite files or worker state left by a failed run.
archive=out/'C23_VANITY_LOGS.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for path in sorted(raw.rglob('*')):
  if path.is_file():
   assert (b'PRIVATE '+b'KEY-----') not in path.read_bytes(),path
   tar.add(path,arcname=str(path.relative_to(raw)))
artifacts.append(archive)
source=[p for p in subprocess.check_output(['git','diff','--name-only','984c4af..HEAD'],text=True).splitlines()
        if not p.startswith('docs/') and p!='README.md']
local=read(raw/'local/final-metadata.json');remote=read(raw/'cuda/keyhunt-vanity-cuda-final-metadata.json')
manifest={
 'milestone':'C23 Bitcoin P2PKH vanity prefix family','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'passed':True,'whole_c23_complete':False,'pending_families':['minikeys','other GPU modes'],
 'scope':'Native HIP/CUDA exact case-sensitive P2PKH prefix matching, overlapping encoding relations, exact scalar recovery and authenticated/offline workers',
 'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'production_last_changed_commit':'9620ee8','schema_version':7,'schema_migrations_changed':False,
 'checks':checks,'base58_vectors_per_backend':345,'search_cases_per_kernel_per_backend':50,
 'rejections_per_kernel_per_backend':31,'native_fault_boundaries_per_backend':31,
 'maximum_overlapping_relations_per_scalar_tested':68,'coordinator_overlapping_relations_tested':16,
 'source_sha256':{p:digest(repo/p) for p in source},
 'final_binaries_sha256':dict(local['binaries'],cuda=remote['binaries']),
 'hardware':{b:reports[b]['direct']['inventory'] for b in reports},
 'local_final_metadata':local,'cuda_final_metadata':remote,
 'artifacts_sha256':{str(p.relative_to(repo)):digest(p) for p in artifacts},
 'raw_files_sha256':{str(p.relative_to(raw)):digest(p) for p in sorted(raw.rglob('*')) if p.is_file()},
 'limitations':['Bitcoin mainnet P2PKH, exact case-sensitive prefixes only',
  'Legacy -m paths retain their CPU behavior; minikeys and other candidate mappings remain pending',
  'No vanity throughput, multi-device scaling, calibration, tuning, partition or MIG certification claim',
  'Coordinator acceptance uses isolated localhost mTLS on each validation host; no public deployment'],
 'findings':['Full Base58Check generation preserves leading zeroes and checksum suffix matches',
  'Distinct prefix lengths per encoding bound output, preserving every overlapping relation while avoiding target-count capacity requirements',
  'Canonical 36-byte targets preserve encoding, length, case and zero padding through local journals and authenticated file exchange',
  'Vanity requires an explicit fifth capability before allocation, renewal, update or cached receipt replay',
  'CPU libbase58, GPU fixed-storage conversion and Python integer Base58 form separate validation paths',
  'GPU family translation units remain separate while scalar checkpoint ownership and recovery are shared'],
 'evidence_policy':'Phased acceptance: logs identify source content phases even where changes were committed after the local build. Embedded binary hashes identify each search artifact. The later coordinator overlap test is recorded separately. Final binaries are not claimed identical to earlier algorithm-test binaries. Archive excludes credential contents and databases.'}
save('C23_VANITY_VALIDATION.json',manifest)
print('Vanity evidence verified:',len(source),'source files,',len(manifest['raw_files_sha256']),'raw files')
