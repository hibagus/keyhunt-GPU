"""Record GPU process identities during benchmarks without reading arguments."""
import csv
import json
import os
from pathlib import Path
import subprocess
import time

root = Path('/var/tmp/keyhunt-c20-validation')
allowed = '/home/bagus/keyhunt-GPU/build/cuda-c20/'
with (root / 'gpu-processes.jsonl').open('w') as output:
    while not (root / 'monitor-stop').exists():
        result = subprocess.run(['nvidia-smi', '--query-compute-apps=pid,gpu_uuid,process_name',
                                 '--format=csv,noheader'], capture_output=True, text=True, timeout=10)
        rows = []
        for row in csv.reader(result.stdout.splitlines()):
            if len(row) != 3:
                continue
            pid, uuid, name = (value.strip() for value in row)
            try:
                executable = os.readlink('/proc/' + str(int(pid)) + '/exe')
            except (FileNotFoundError, PermissionError, ValueError):
                executable = None
            rows.append(dict(pid=pid, uuid=uuid, executable=executable, reported_name=name,
                             known_foreign=bool(executable and not executable.startswith(allowed))))
        output.write(json.dumps(dict(utc_ns=time.time_ns(), returncode=result.returncode, processes=rows)) + '\n')
        output.flush()
        time.sleep(2)
