"""Paired real-worker startup timings; keep GPU kernels and inputs identical."""
import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess
import time

root = Path('/var/tmp/keyhunt-c20-validation')
binary = Path('/home/bagus/keyhunt-GPU/build/cuda-c20/keyhunt-worker')
report = dict(binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(), runs=[], passed=False,
              variable='CUDA_FORCE_PRELOAD_LIBRARIES', selected_ordinal=7,
              note='Fresh-process wall time for the production xpoint/BSGS worker self-test, not kernel time.')
expected = None
for repetition in range(6):
    # Reverse order each pair to avoid always measuring one policy first.
    variants = ('default', 'lazy') if repetition % 2 == 0 else ('lazy', 'default')
    for variant in variants:
        env = os.environ.copy()
        env.pop('CUDA_FORCE_PRELOAD_LIBRARIES', None)
        if variant == 'lazy':
            env['CUDA_FORCE_PRELOAD_LIBRARIES'] = '0'
        started = time.monotonic_ns()
        completed = subprocess.run([str(binary), 'self-test', '--device', '7'],
                                   env=env, capture_output=True, text=True, timeout=30, check=True)
        wall_ns = time.monotonic_ns() - started
        result = json.loads(completed.stdout)
        assert result['passed'] is True and result['ordinal'] == 7 and not completed.stderr
        if expected is None:
            expected = result
        assert result == expected, (result, expected)
        report['runs'].append(dict(variant=variant, repetition=repetition, measured=repetition > 0,
                                   wall_ns=wall_ns, self_test=result))
        print(variant, repetition, wall_ns / 1e9, flush=True)
report['medians_seconds'] = {variant: statistics.median(row['wall_ns'] / 1e9 for row in report['runs']
                            if row['measured'] and row['variant'] == variant)
                            for variant in ('default', 'lazy')}
report['speedup'] = report['medians_seconds']['default'] / report['medians_seconds']['lazy']
report['passed'] = True
(root / 'C20_CUDA_STARTUP.json').write_text(json.dumps(report, indent=2) + '\n')
