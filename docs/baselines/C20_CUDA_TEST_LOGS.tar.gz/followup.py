"""Run GPU-only follow-up checks after the independently logged CTest suite."""
import json
import os
from pathlib import Path
import subprocess
import time
import xml.etree.ElementTree as ET

repo = Path('/home/bagus/keyhunt-GPU')
build = repo / 'build/cuda-c20'
evidence = Path('/var/tmp/keyhunt-c20-validation')
# CTest writes JUnit only when the run ends. No benchmarks overlap the suite.
deadline = time.monotonic() + 2400
while not (evidence / 'tests.xml').exists():
    if time.monotonic() >= deadline:
        raise TimeoutError('CUDA suite did not finish within 40 minutes')
    time.sleep(5)
tests = ET.parse(evidence / 'tests.xml').getroot()
assert int(tests.attrib['tests']) == 64, tests.attrib
assert int(tests.attrib.get('failures', 0)) == 0, tests.attrib
assert not any(case.find('skipped') is not None for case in tests.iter('testcase'))

env = os.environ.copy()
env['TMPDIR'] = '/var/tmp'
def run(label, args, timeout, extra_env=None):
    started = time.monotonic()
    with (evidence / (label + '.log')).open('w') as output:
        result = subprocess.run(args, cwd=repo, env=env if extra_env is None else dict(env, **extra_env),
                                stdout=output, stderr=subprocess.STDOUT, timeout=timeout)
    print(f'{label}: exit={result.returncode}, seconds={time.monotonic() - started:.3f}', flush=True)
    result.check_returncode()

sanitizers = []
for executable in ('cuda_xpoint_executor_test', 'cuda_bsgs_search_test'):
    label = 'memcheck-' + executable
    args = ['/usr/local/cuda/bin/compute-sanitizer', '--tool', 'memcheck',
            '--leak-check', 'full', '--error-exitcode', '99']
    # The xpoint lifecycle fixture deliberately sends an invalid device ordinal.
    # Suppress expected SDK error reports there, while retaining memory/leak checks.
    if executable == 'cuda_xpoint_executor_test':
        args += ['--report-api-errors', 'no']
    args += [str(build / executable)]
    run(label, args, 240, {'CUDA_VISIBLE_DEVICES': '7'})
    text = (evidence / (label + '.log')).read_text()
    assert 'ERROR SUMMARY: 0 errors' in text, text[-2000:]
    sanitizers.append(dict(executable=executable, tool='memcheck', passed=True,
                           physical_device=7, command=args))
label = 'memcheck-worker-self-test'
args = ['/usr/local/cuda/bin/compute-sanitizer', '--tool', 'memcheck', '--leak-check', 'full',
        '--error-exitcode', '99', str(build / 'keyhunt-worker'), 'self-test', '--device', '7']
run(label, args, 240)
assert 'ERROR SUMMARY: 0 errors' in (evidence / (label + '.log')).read_text()
sanitizers.append(dict(executable='keyhunt-worker self-test --device 7', tool='memcheck',
                       passed=True, physical_device=7, command=args))
(evidence / 'sanitizers.json').write_text(json.dumps(sanitizers, indent=2) + '\n')
# The interactive owner releases this gate after checking external GPU load.
print('Memory checks passed; waiting for a quiet benchmark window', flush=True)
quiet_deadline = time.monotonic() + 2400
while not (evidence / 'benchmark-ready').exists():
    if time.monotonic() >= quiet_deadline:
        raise TimeoutError('No quiet benchmark window was available within 40 minutes')
    time.sleep(5)
common = ['python3', 'tools/validate_fleet.py', '--build-dir', str(build),
          '--apache-root', '/tmp/keyhunt-c20-deps/root', '--backend', 'cuda']
run('fleet', common + ['--counts', '1,2,4,8', '--repeat', '5', '--block-bits', '32',
                      '--output', str(evidence / 'C20_CUDA_FLEET.json')], 1500)
run('lifecycle', common + ['--counts', '2', '--lifecycle-only', '--reference-report',
                          str(evidence / 'C20_CUDA_FLEET.json'), '--reference-device', '0',
                          '--output', str(evidence / 'C20_CUDA_LIFECYCLE.json')], 360)
print('H200 follow-up validation passed', flush=True)
