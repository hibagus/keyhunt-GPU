from pathlib import Path
import datetime,hashlib,json,re,subprocess,tarfile
repo=Path.cwd();raw=Path('/var/tmp/keyhunt-c23-minikey-evidence');out=repo/'docs/baselines'
def read(path):return json.loads(path.read_text())
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(name,value):
 path=out/name;path.write_text(json.dumps(value,indent=2)+'\n');return path
reports={}
for backend in ('hip','cuda'):
 reports[backend]={
  'mapping_sha_vectors':read(raw/backend/f'{backend}-minikey-oracle.json'),
  'search':read(raw/backend/'minikeys-cli-results.json'),
  'checkpoints':read(raw/backend/'checkpoint-minikeys-cli.json'),
  'shared_checkpoints':read(raw/backend/'checkpoint-cli-results.json'),
  'pause':read(raw/backend/f'checkpoint-minikeys-pause-{backend}.json'),
  'offline':read(raw/backend/'coordinator-offline-cli.json'),
  'examples':read(raw/backend/f'keyhunt-minikey-examples-{backend}.json')}
 vectors=reports[backend]['mapping_sha_vectors'];assert vectors['cases']==1781 and vectors['passed'] and vectors['admitted']==12
 search=reports[backend]['search'];assert search['passed'] and len(search['cases'])==70 and search['rejections']==32 and search['inspections']==4
 assert len(search['inventory']['devices'])==8
 assert all(c['summary']['complete'] for c in search['cases'])
 for kind in ('checkpoints','shared_checkpoints','pause','offline','examples'):assert reports[backend][kind]['passed']
 assert len(reports[backend]['checkpoints']['cases'])==8
 assert reports[backend]['pause']['changed_inventory_tested']
 assert [c['mode'] for c in reports[backend]['pause']['cases']]==['minikeys22','minikeys30']
 assert [c['mode'] for c in reports[backend]['offline']['cases']]==['xpoint','bsgs','hash160','ethereum','vanity','minikeys22','minikeys30']
 for case in reports[backend]['offline']['cases'][-2:]:
  assert len(case['local_results']['results'])==len(case['server_results'])==2
  assert all(len(r['target_bytes'])==44 and r['coordinate_space']=='minikey-ordinal-v1' and r['ordinal']!=r['scalar'] for r in case['local_results']['results'])
  assert len(case['blocks'])==2 and case['final_status']['outbox_bytes']==0
  finished=[e for e in case['events'] if e.get('type')=='grant-finish']
  assert len(finished)==2 and all(e['executor_setups']==1 and e['mode']=='minikeys' and int(e['computed_ordinals'],16)==512 for e in finished)
  assert finished[0]['cold'] and not finished[1]['cold']
artifacts=[]
for label,keys in [('ALGORITHMS',('mapping_sha_vectors','search')),('RECOVERY',('checkpoints','shared_checkpoints','pause')),('OFFLINE',('offline',))]:
 artifacts.append(save(f'C23_MINIKEYS_{label}.json',{b:{k:reports[b][k] for k in keys} for b in reports}))
examples={b:reports[b]['examples'] for b in reports};examples['cpu']=read(raw/'local/keyhunt-minikey-examples-cpu.json')
assert all(r['passed'] and r['document_sha256']==digest(repo/'docs/GPU_QUICKSTART.md') for r in examples.values())
artifacts.append(save('C23_MINIKEYS_EXAMPLES.json',examples))
phases={'algorithms':subprocess.check_output(['git','rev-parse','503ff73'],text=True).strip(),
        'storage':subprocess.check_output(['git','rev-parse','ce2d7a6'],text=True).strip(),
        'workers':subprocess.check_output(['git','rev-parse','2beda4c'],text=True).strip(),
        'api_boundary':subprocess.check_output(['git','rev-parse','0361b2d'],text=True).strip(),
        'examples':subprocess.check_output(['git','rev-parse','1efb7d3'],text=True).strip()}
specs=[('asan_ubsan','local/keyhunt-minikey-asan-tests.log',36,'workers'),
 ('hip_algorithms','hip/algorithms.log',6,'algorithms'),
 ('cuda_algorithms','cuda/keyhunt-minikey-cuda-algorithms.log',6,'algorithms'),
 ('hip_recovery_regression','hip/keyhunt-minikey-hip-final-tests.log',18,'workers'),
 ('cuda_recovery_regression','cuda/keyhunt-minikey-cuda-final-tests.log',19,'workers'),
 ('cpu_offline_corrected','local/keyhunt-minikey-cpu-offline-recheck.log',1,'workers'),
 ('cpu_api_boundary','local/keyhunt-minikey-cpu-boundary-tests.log',1,'api_boundary'),
 ('asan_api_boundary','local/keyhunt-minikey-asan-boundary-tests.log',1,'api_boundary'),
 ('hip_api_boundary','hip/keyhunt-minikey-hip-boundary-tests.log',1,'api_boundary'),
 ('cuda_api_boundary','cuda/keyhunt-minikey-cuda-boundary-tests.log',1,'api_boundary')]
checks={}
for name,log,count,phase in specs:
 text=(raw/log).read_text();assert f'100% tests passed, 0 tests failed out of {count}' in text,(name,text[-1500:])
 checks[name]={'passed':count,'failed':0,'log':log,'source_phase':phases[phase]}
# Preserve the failed fixture run and its correction openly. Every other CPU
# case passed in the full run; the exact failed test passes the separate rerun.
log='local/keyhunt-minikey-cpu-tests.log';text=(raw/log).read_text()
passed=re.findall(r'Test\s+#\d+: (\S+)\s+\.+\s+Passed',text)
failed=re.findall(r'Test\s+#\d+: (\S+)\s+\.+\*\*\*Failed',text)
assert len(passed)==72 and failed==['coordinator_offline_cli'],(len(passed),failed)
checks['cpu_release']={'passed_after_correction':73,'initial_passed':72,'initial_failed':failed,
 'log':log,'correction_log':'local/keyhunt-minikey-cpu-offline-recheck.log','source_phase':phases['workers']}
archive=out/'C23_MINIKEYS_LOGS.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for path in sorted(raw.rglob('*')):
  if path.is_file():
   assert (b'PRIVATE '+b'KEY-----') not in path.read_bytes(),path
   tar.add(path,arcname=str(path.relative_to(raw)))
artifacts.append(archive)
source=[p for p in subprocess.check_output(['git','diff','--name-only','4ad0abe..HEAD'],text=True).splitlines()
        if not p.startswith('docs/') and p!='README.md']
local=read(raw/'local/final-metadata.json');remote=read(raw/'cuda/keyhunt-minikey-cuda-final-metadata.json')
manifest={
 'milestone':'C23 minikey 22/30 family','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'passed':True,'whole_c23_complete':False,'pending_families':['other candidate mappings outside the agreed 22/30 SHA-256 minikey scope'],
 'scope':'Native HIP/CUDA exact minikey candidate ordinals, both public-key encodings, durable recovery and authenticated/offline workers',
 'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'source_phases':phases,'production_last_changed_commit':phases['api_boundary'],'schema_version':7,'schema_migrations_changed':False,
 'checks':checks,'mapping_sha_vectors_per_backend':1781,'search_cases_per_backend':70,
 'rejections_per_backend':32,'native_fault_boundaries_per_backend':29,'lengths':[22,30],
 'max_batch_ordinals_per_length':1048576,'admitted_in_max_batch':{'22':4193,'30':4261},
 'source_sha256':{p:digest(repo/p) for p in source},
 'final_binaries_sha256':dict(local['binaries'],cuda=remote['binaries']),
 'hardware':{b:reports[b]['search']['inventory'] for b in reports},
 'local_final_metadata':local,'cuda_final_metadata':remote,
 'artifacts_sha256':{str(p.relative_to(repo)):digest(p) for p in artifacts},
 'raw_files_sha256':{str(p.relative_to(raw)):digest(p) for p in sorted(raw.rglob('*')) if p.is_file()},
 'limitations':['SHA-256 minikey lengths 22 and 30, standard Base58 suffix, Bitcoin mainnet P2PKH/HASH160 only',
  'Legacy -m paths retain CPU behavior; length 26, PBKDF2, custom alphabets and random traversal are outside this slice',
  'No minikey throughput, multi-device scaling, calibration, tuning, partition or MIG certification claim',
  'Coordinator acceptance uses isolated localhost mTLS on each host; no public deployment'],
 'findings':['One-based fixed-width Base58 ordinals cover every candidate including invalid check bytes',
  'Internal mode-6 receipt scalar fields are ordinal coordinates; public result fields separate ordinal, text and derived scalar',
  'Direct scalar derivation is necessary because adjacent candidate hashes are unrelated; no point-stepping or power cache applies',
  'Canonical length/encoding/HASH160 targets preserve identity through recovery and authenticated file exchange',
  'Minikey jobs require an explicit sixth capability before allocation, renewal, updates or cached replay',
  'Two fixture variable collisions were corrected; the original CPU failure and successful offline rerun are retained',
  'Out-of-domain minikey creation is explicitly HTTP 400 before persistence, covered by final focused checks',
  'Supervisor leaves an unspecified kernel to mode defaults and rejects explicit stepped minikey execution'],
 'evidence_policy':'Phased acceptance: source commits identify algorithm, storage, worker, example and final API-boundary content. The focused final boundary checks are separate from the earlier integrated worker gates. Embedded hashes identify each algorithm artifact, separately from final worker binaries. CPU offline fixture correction is recorded as a rerun, not hidden as an initial pass. Archive excludes credential contents and databases.'}
save('C23_MINIKEYS_VALIDATION.json',manifest)
print('Minikey evidence verified:',len(source),'source files,',len(manifest['raw_files_sha256']),'raw files')
