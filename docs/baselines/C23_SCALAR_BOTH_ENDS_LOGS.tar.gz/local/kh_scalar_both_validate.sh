#!/usr/bin/env bash
set -euo pipefail
repo=/home/bagus/keyhunt-GPU
kind="$1"
case "$kind" in
  local) build="$repo/build/coordinator-release"; filter='.'; jobs=6;;
  sanitizer) build="$repo/build/coordinator-sanitizers"; filter='^(scalar_batch_oracle|storage_scalar_both_ends|coordinator_scalar_both_ends|work_unit|storage_(stride|reverse|orbit)_checkpoint|coordinator_(strides|reverse|orbits))$'; jobs=4;;
  hip) build="$repo/build/hip-release"; filter='scalar_both_ends|scalar_batch_oracle|^scalar_(strides|reverse|orbit_(forward|reverse))_cli$|^glv_(forward|reverse)_cli$|^work_unit$|^(hip|cuda)_(stride|reverse|glv_xpoint)_executor$|^storage_(stride|reverse|orbit)_checkpoint$|^coordinator_(strides|reverse|orbits)$'; jobs=4;;
  cuda) build="$repo/build/cuda-h200"; filter='scalar_both_ends|scalar_batch_oracle|^scalar_(strides|reverse|orbit_(forward|reverse))_cli$|^glv_(forward|reverse)_cli$|^work_unit$|^(hip|cuda)_(stride|reverse|glv_xpoint)_executor$|^storage_(stride|reverse|orbit)_checkpoint$|^coordinator_(strides|reverse|orbits)$'; jobs=4;;
  *) exit 2;;
esac
raw="/var/tmp/keyhunt-c23-scalar-both-ends-evidence/$kind"
mkdir -p "$raw"
ctest --test-dir "$build" -R "$filter" --show-only=json-v1 > "$raw/selection.json"
python3 /tmp/kh_scalar_both_metadata.py "$repo" "$build" "$raw/selection.json" > "$raw/build-metadata.json"
export TMPDIR=/var/tmp KEYHUNT_KECCAK_ORACLE_ROOT=/var/tmp/keyhunt-c23-ethereum-oracle
ctest --test-dir "$build" --output-on-failure -j "$jobs" -R "$filter" --output-junit "$raw/tests.xml" > "$raw/tests.log" 2>&1
python3 /tmp/kh_scalar_both_collect.py "$build" "$raw" "$raw/selection.json"
