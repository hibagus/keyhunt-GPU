import hashlib,json,tarfile,xml.etree.ElementTree as ET
from pathlib import Path
repo=Path('/home/bagus/keyhunt-GPU');raw=Path('/var/tmp/keyhunt-c23-scalar-both-ends-evidence');out=repo/'docs/baselines'
source='0d2704b6f3ae15d240d9d51a7d8eaeaa14d2f2f4'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
manifest=dict(feature='C23 scalar both-ends batch traversal',source_commit=source,previous_acceptance='a34ab2f8822bd703627d92a4bb1e80a197816c65',passed=True,phases=dict(contract='6d71977',implementation='cb24cec',native='cd16461',recovery='88df111',workers='fa1c59f',example='36bc698',guides='0d2704b'),suites={},artifacts={})
for kind,count in [('local',172),('sanitizer',10),('hip',29),('cuda',29)]:
 directory=raw/kind;xml=ET.parse(directory/'tests.xml').getroot();tests=xml.findall('testcase')
 assert len(tests)==count,(kind,len(tests))
 assert 'Passed 240 scalar both-ends recovery combinations' in (directory/'LastTest.log').read_text()
 assert all(t.find('failure') is None and t.find('skipped') is None for t in tests),kind
 meta=read(directory/'build-metadata.json');assert meta['source_commit']==source
 manifest['suites'][kind]=dict(tests=count,seconds=xml.get('time'),metadata=meta,results=[dict(name=t.get('name'),seconds=t.get('time')) for t in tests])
algorithms={};recovery={};workers={};examples={}
for kind in ('local','hip','cuda'):
 directory=raw/kind;meta=manifest['suites'][kind]['metadata'];binary=meta['binaries']['keyhunt']
 algorithms[kind]={};recovery[kind]={};workers[kind]={}
 for p in sorted(directory.glob('*.json')):
  name=p.name
  if not any(name.startswith(v) for v in ('scalar-both-ends-','scalar-batch-oracle','checkpoint-scalar-both-ends','coordinator-scalar-both-ends')):continue
  v=read(p);assert v['passed'],p
  if name=='scalar-batch-oracle.json':assert v['binary_sha256']==meta['binaries']['scalar_batch_probe']
  elif 'coordinator-' in name:
   assert v['binaries']['keyhunt']==binary and v['binaries']['keyhunt-worker']==meta['binaries']['keyhunt-worker']
  else:assert v['binary_sha256']==binary,p
  if 'example' in name:
   assert v['document_sha256']==sha(repo/'docs/C23_SCALAR_BOTH_ENDS.md');examples[kind]=v
  elif name.startswith('checkpoint'):recovery[kind][name]=v
  elif name.startswith('coordinator'):workers[kind][name]=v
  else:algorithms[kind][name]=v
 assert len(algorithms[kind])==5 and len(workers[kind])==2
 assert len(recovery[kind])==(2 if kind=='local' else 3)
san=read(raw/'sanitizer/scalar-batch-oracle.json')
assert san['passed'] and san['cases']==1447
assert san['binary_sha256']==manifest['suites']['sanitizer']['metadata']['binaries']['scalar_batch_probe']
for kind in ('hip','cuda'):
 for name,count in [('strides-forward',188),('strides-reverse',203),('orbits-forward',103),('orbits-reverse',98)]:
  value=algorithms[kind]['scalar-both-ends-'+name+'.json']
  assert len(value['cases'])==count and len(value['inventory']['devices'])==8
 for value in workers[kind].values():assert len(value['cases'])==8
 for name,value in recovery[kind].items():assert len(value['cases'])==(4 if 'pause' in name else 28)
assert all(v['cases']==1447 and v['max_owners']==2 for kind in algorithms for name,v in algorithms[kind].items() if name=='scalar-batch-oracle.json')
for title,value in [('ALGORITHMS',algorithms),('RECOVERY',recovery),('WORKERS',workers),('EXAMPLES',examples)]:
 p=out/f'C23_SCALAR_BOTH_ENDS_{title}.json';p.write_text(json.dumps(value,indent=2)+'\n');manifest['artifacts'][p.name]=sha(p)
archive=out/'C23_SCALAR_BOTH_ENDS_LOGS.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(raw.rglob('*')):
  if p.is_file():tar.add(p,arcname=str(p.relative_to(raw)),recursive=False)
manifest['artifacts'][archive.name]=sha(archive)
manifest['raw_files']={str(p.relative_to(raw)):sha(p) for p in sorted(raw.rglob('*')) if p.is_file()}
manifest['development_findings']=[
 'The initial host build required an explicit vector include in the new planner header.',
 'The recovery fixture exposed rejection of completed grants with executor generation zero; production validation now requires a live generation only when work remains.',
 'The initial recovery fixture requested pause at completion; it now uses a one-step resumed batch to exercise an actual partial pause.',
 'The fixture now requests all results instead of relying on the default 100-row page.',
 'An empty CTest regular expression selected zero CPU tests; this was replaced with an explicit match-all expression before the full suite.'
]
(out/'C23_SCALAR_BOTH_ENDS_VALIDATION.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({kind:sum(len(v.get('cases',[])) for name,v in data.items() if name!='scalar-batch-oracle.json') for kind,data in algorithms.items()}))
print('PASS bound artifacts for',source)
