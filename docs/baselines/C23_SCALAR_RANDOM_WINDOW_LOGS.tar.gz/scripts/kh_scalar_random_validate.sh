#!/usr/bin/env bash
set -euo pipefail
repo=/home/bagus/keyhunt-GPU
kind="$1"
case "$kind" in
  local) build="$repo/build/coordinator-release"; filter='.'; jobs=6;;
  sanitizer) build="$repo/build/coordinator-sanitizers"; filter='^(scalar_(batch|random_window)_oracle|storage_scalar_(random_window|dance|both_ends)|coordinator_scalar_(random_window|dance|both_ends)|work_unit)$'; jobs=4;;
  hip|cuda)
    if [ "$kind" = hip ]; then build="$repo/build/hip-release"; else build="$repo/build/cuda-h200"; fi
    filter='scalar_random_window|scalar_batch_oracle|^work_unit$|^(hip|cuda)_(stride|reverse|glv_xpoint)_executor$|^storage_scalar_(both_ends|dance)$|^coordinator_scalar_(both_ends|dance)$'; jobs=4;;
  *) exit 2;;
esac
raw="/var/tmp/keyhunt-c23-scalar-random-window-evidence/$kind"
mkdir -p "$raw"
ctest --test-dir "$build" -R "$filter" --show-only=json-v1 > "$raw/selection.json"
python3 /tmp/kh_scalar_both_metadata.py "$repo" "$build" "$raw/selection.json" > "$raw/build-metadata.json"
export TMPDIR=/var/tmp KEYHUNT_KECCAK_ORACLE_ROOT=/var/tmp/keyhunt-c23-ethereum-oracle
ctest --test-dir "$build" --output-on-failure -j "$jobs" -R "$filter" --output-junit "$raw/tests.xml" > "$raw/tests.log" 2>&1
python3 /tmp/kh_scalar_both_collect.py "$build" "$raw" "$raw/selection.json"
