import hashlib,json,re,tarfile,xml.etree.ElementTree as ET
from pathlib import Path
repo=Path('/home/bagus/keyhunt-GPU');raw=Path('/var/tmp/keyhunt-c23-scalar-random-window-evidence');out=repo/'docs/baselines'
source='648e9092e8e333e7fd470b9a130e097ca2e8885a'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
manifest=dict(feature='C23 seeded scalar random-window traversal',source_commit=source,previous_acceptance='b9b2f3de5916b4bb0ac0e900a77cd9b2edcf993d',passed=True,phases=dict(contract='546cf5a',hash_library='79ccf1a',planner='6681108',interfaces='85f710a',native='199a74b',recovery='ac15368',workers='2efa1a3',example='e0289a7',guides='648e909'),suites={},artifacts={})
for kind,count in [('local',195),('sanitizer',9),('hip',22),('cuda',22)]:
 directory=raw/kind;xml=ET.parse(directory/'tests.xml').getroot();tests=xml.findall('testcase')
 assert len(tests)==count,(kind,len(tests))
 assert 'Passed 240 scalar both-ends recovery combinations' in (directory/'LastTest.log').read_text()
 assert 'Passed 400 scalar dance recovery combinations' in (directory/'LastTest.log').read_text()
 assert 'Passed 560 scalar random-window recovery combinations' in (directory/'LastTest.log').read_text()
 assert all(t.find('failure') is None and t.find('skipped') is None for t in tests),kind
 meta=read(directory/'build-metadata.json');assert meta['source_commit']==source
 manifest['suites'][kind]=dict(tests=count,seconds=xml.get('time'),ctest_seconds=float(re.search(r'Total Test time \(real\) = ([0-9.]+) sec',(directory/'tests.log').read_text())[1]),metadata=meta,results=[dict(name=t.get('name'),seconds=t.get('time')) for t in tests])
algorithms={};recovery={};workers={};examples={}
for kind in ('local','hip','cuda'):
 directory=raw/kind;meta=manifest['suites'][kind]['metadata'];binary=meta['binaries']['keyhunt']
 algorithms[kind]={};recovery[kind]={};workers[kind]={}
 for p in sorted(directory.glob('*.json')):
  name=p.name
  if not any(name.startswith(v) for v in ('scalar-random-window-','scalar-batch-oracle','checkpoint-scalar-random-window','coordinator-scalar-random-window')):continue
  v=read(p);assert v['passed'],p
  if name.endswith('-oracle.json'):assert v['binary_sha256']==meta['binaries']['scalar_batch_probe']
  elif 'coordinator-' in name:
   assert v['binaries']['keyhunt']==binary and v['binaries']['keyhunt-worker']==meta['binaries']['keyhunt-worker']
  else:assert v['binary_sha256']==binary,p
  if 'example' in name:
   assert v['document_sha256']==sha(repo/'docs/C23_SCALAR_RANDOM_WINDOW.md');examples[kind]=v
  elif name.startswith('checkpoint'):recovery[kind][name]=v
  elif name.startswith('coordinator'):workers[kind][name]=v
  else:algorithms[kind][name]=v
 assert len(algorithms[kind])==6 and len(workers[kind])==2
 assert len(recovery[kind])==(2 if kind=='local' else 3)
san=read(raw/'sanitizer/scalar-random-window-oracle.json')
assert san['passed'] and san['cases']==2500
assert san['binary_sha256']==manifest['suites']['sanitizer']['metadata']['binaries']['scalar_batch_probe']
for kind in ('hip','cuda'):
 for name,count in [('strides-forward',203),('strides-reverse',203),('orbits-forward',103),('orbits-reverse',98)]:
  value=algorithms[kind]['scalar-random-window-'+name+'.json']
  assert len(value['cases'])==count and len(value['inventory']['devices'])==8
 for value in workers[kind].values():assert len(value['cases'])==8
 for name,value in recovery[kind].items():assert len(value['cases'])==(4 if 'pause' in name else 28)
assert all(v['cases']==2174 and v['max_owners']==3 for kind in algorithms for name,v in algorithms[kind].items() if name=='scalar-batch-oracle.json')
for kind in algorithms:
 v=algorithms[kind]['scalar-random-window-oracle.json']
 assert v['cases']==2500 and v['unaccepted_attempts']==39445 and v['rejected_draws']==10762 and v['max_active_units']==72 and v['max_extra_fragments']==69
for title,value in [('ALGORITHMS',algorithms),('RECOVERY',recovery),('WORKERS',workers),('EXAMPLES',examples)]:
 p=out/f'C23_SCALAR_RANDOM_WINDOW_{title}.json';p.write_text(json.dumps(value,indent=2)+'\n');manifest['artifacts'][p.name]=sha(p)
archive=out/'C23_SCALAR_RANDOM_WINDOW_LOGS.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(raw.rglob('*')):
  if p.is_file():tar.add(p,arcname=str(p.relative_to(raw)),recursive=False)
manifest['artifacts'][archive.name]=sha(archive)
manifest['raw_files']={str(p.relative_to(raw)):sha(p) for p in sorted(raw.rglob('*')) if p.is_file()}
manifest['decisions']=[
 'Ascending canonical tiles and original contiguous owners are frozen before a bounded Fisher-Yates shuffle; there are at most W tiles and W owners beyond the input gaps.',
 'The SHA-256 domain is khscalar-window-v1 followed by a zero byte and 32-byte big-endian seed/counter. First-byte mask/rejection sampling specifies portable order.',
 'Selected tile suffixes remain selected through overflow, batch growth and orbit clipping. Completion uses the actual batch interval so an orbit boundary cannot skip work.',
 'Restart resets the stream over the saved complement and permits changed order, seed, window, geometry and device without changing scalar mappings or durable identities.',
 'Portable SHA-256 is a shared library; exact scheduling remains independent of the legacy curve engine.'
]
manifest['development_findings']=['No production or test failures were observed in the recorded acceptance runs.']
manifest['limits']=['Synthetic public fixtures; no throughput or discovery-probability claim.','Local bounded shuffles, not uniform global sampling or sampling with replacement.','C23 completion is scoped to the documented exact GPU interfaces; historical CPU defects and inactive pub2rmd remain documented separately.']
(out/'C23_SCALAR_RANDOM_WINDOW_VALIDATION.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({kind:sum(len(v.get('cases',[])) for name,v in data.items() if not name.endswith('-oracle.json')) for kind,data in algorithms.items()}))
print('PASS bound artifacts for',source)
