import hashlib,json,platform,subprocess,sys
from pathlib import Path
repo=Path(sys.argv[1]);build=Path(sys.argv[2]);selection=Path(sys.argv[3])
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
names={'keyhunt','keyhunt-worker','keyhunt-coordinator','secp256k1_oracle'}
for test in json.loads(selection.read_text())['tests']:
 for arg in test['command']:
  p=Path(arg)
  if p.parent==build and p.is_file() and not p.suffix:names.add(p.name)
keys=('CMAKE_BUILD_TYPE','CMAKE_CXX_COMPILER','CMAKE_HIP_COMPILER','CMAKE_CUDA_COMPILER','CMAKE_CUDA_ARCHITECTURES','CMAKE_HIP_ARCHITECTURES','KEYHUNT_ENABLE_CUDA','KEYHUNT_ENABLE_HIP','KEYHUNT_ENABLE_COORDINATOR','KEYHUNT_ENABLE_HTTPS_WORKER','KEYHUNT_ENABLE_SANITIZERS','KEYHUNT_ENABLE_LTO','KEYHUNT_GFX942_CARRY')
config={line.split(':')[0]:line.split('=',1)[1] for line in (build/'CMakeCache.txt').read_text().splitlines() if ':' in line and '=' in line and line.split(':')[0] in keys}
compilers={v for k,v in config.items() if k.endswith('_COMPILER')}
print(json.dumps(dict(source_commit=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),platform=platform.platform(),binaries={n:sha(build/n) for n in sorted(names) if (build/n).is_file()},configuration=config,compilers={c:subprocess.check_output([c,'--version'],text=True).strip() for c in sorted(compilers)}),indent=2))
