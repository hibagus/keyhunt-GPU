import json,shutil,sys
from pathlib import Path
build,raw,selection=map(Path,sys.argv[1:])
for test in json.loads(selection.read_text())['tests']:
 if not any(v in test['name'] for v in ('scalar','stride','reverse','orbit','glv','work_unit')):continue
 cmd=test['command']
 if '--report' in cmd:
  p=Path(cmd[cmd.index('--report')+1]);value=json.loads(p.read_text());assert not isinstance(value,dict) or value.get('passed',True),p
  shutil.copy2(p,raw/p.name)
shutil.copy2(build/'Testing/Temporary/LastTest.log',raw/'LastTest.log')
