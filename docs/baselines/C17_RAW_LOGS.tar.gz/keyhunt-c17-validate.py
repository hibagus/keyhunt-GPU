import concurrent.futures, datetime, json, os, pathlib, subprocess, time
root=pathlib.Path('/home/bagus/keyhunt-GPU')
report_path=pathlib.Path('/tmp/keyhunt-c17-validation-runs.json')
report={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runs':{}}
# Keep correctness jobs and profiling out of the timed benchmark/pause window.
deadline=time.monotonic()+1200
while True:
    try:
        pause=json.loads(pathlib.Path('/tmp/keyhunt-c17-pause-final.json').read_text())
        matrix=json.loads(pathlib.Path('/tmp/keyhunt-c17-final-pair/report.json').read_text())
        if pause.get('passed') and matrix.get('passed'):break
    except (FileNotFoundError,json.JSONDecodeError):pass
    if time.monotonic()>deadline:raise RuntimeError('acceptance measurements did not finish successfully')
    time.sleep(2)

def run(name,words,timeout=1200):
    log=pathlib.Path('/tmp/keyhunt-c17-'+name+'.log')
    start=time.monotonic()
    with log.open('w') as stream:
        p=subprocess.run(words,cwd=root,env=dict(os.environ,HIP_VISIBLE_DEVICES='1'),stdout=stream,stderr=subprocess.STDOUT,timeout=timeout)
    result={'command':words,'exit_code':p.returncode,'wall_seconds':time.monotonic()-start,'log':str(log)}
    print(name,p.returncode,flush=True)
    return result

report['runs']['profile']=run('final-profile',['python3','tools/profile_gpu.py','--benchmark','/tmp/keyhunt-c17-groups-live/report.json','--case','bsgs-no-match-32','--output-dir','/tmp/keyhunt-c17-final-profile','--resources'])
report_path.write_text(json.dumps(report,indent=2)+'\n')

def cpu():
    result={}
    selections={'cpu-release':None,
                'cpu-debug':'^(gpu_benchmark_metrics|gpu_benchmark_pairs|portable_(field|point)_oracle|storage_checkpoint|storage_checkpoint_failures|storage_checkpoint_control|checkpoint_cli)$',
                'cpu-sanitizers':'^(gpu_benchmark_metrics|gpu_benchmark_pairs|portable_(field|point)_oracle|storage_checkpoint|storage_checkpoint_control)$'}
    for build,selection in selections.items():
        result[build+'-build']=run(build+'-build',['cmake','--build','build/'+build,'-j8'])
        if result[build+'-build']['exit_code']:continue
        words=['ctest','--test-dir','build/'+build,'--output-on-failure']
        if selection:words+=['-R',selection]
        result[build+'-tests']=run(build+'-tests',words)
    return result

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    host=pool.submit(cpu)
    report['runs']['hip-tests']=run('hip-tests',['ctest','--test-dir','build/hip-release','--output-on-failure'])
    report['runs'].update(host.result())
report['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
report['passed']=all(r['exit_code']==0 for r in report['runs'].values())
report_path.write_text(json.dumps(report,indent=2)+'\n')
print('C17 validation passed:',report['passed'],flush=True)
