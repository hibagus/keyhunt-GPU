import hashlib,json,pathlib,subprocess,sys
root=pathlib.Path('/home/bagus/keyhunt-GPU')
sys.path.insert(0,str(root/'tools'))
from profile_gpu import resource_command
out=pathlib.Path(sys.argv[1]);out.mkdir()
files=['kernels/common/field.h','kernels/common/point.h','kernels/hip/xpoint.h','kernels/hip/bsgs_search.h','src/backend/hip/xpoint.hip','src/backend/hip/bsgs_search.hip']
manifest={'sources':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in files},'commands':[]}
for name in ['xpoint','bsgs_search']:
 e=next(e for e in json.load(open(root/'build/hip-release/compile_commands.json')) if e['file'].endswith('/src/backend/hip/'+name+'.hip') and 'keyhunt_backend.dir' in e['command'])
 cmd=resource_command(e,out/(name+'.s'));manifest['commands'].append(cmd)
 with (out/(name+'-remarks.txt')).open('w') as log:subprocess.run(cmd,cwd=e['directory'],stdout=log,stderr=log,check=True)
manifest['artifacts']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir()}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
