import datetime,hashlib,json,math,pathlib,statistics
root=pathlib.Path('/home/bagus/keyhunt-GPU');reports={}
labels=['launch','mixed','mixed-selective','inverse','inverse-direct','capacity','capacity-large','recovery','final']
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def check_distribution(actual,values):
    med=statistics.median(values)
    expected=dict(count=len(values),median=med,min=min(values),max=max(values),spread=max(values)-min(values),mad=statistics.median(abs(v-med) for v in values))
    assert actual.keys()==expected.keys()
    for k,v in expected.items():assert math.isclose(actual[k],v,rel_tol=1e-14,abs_tol=1e-14),(k,actual[k],v)
for label in labels:
    directory=pathlib.Path('/tmp/keyhunt-c17-'+label+'-pair')
    r=json.loads((directory/'report.json').read_text());assert r['passed'] and not r['failures']
    pairs=[p for p in r['pairs'] if not p['warmup']];assert len(pairs)==5
    distributions=0
    for key,metrics in r['statistics'].items():
        for metric,summary in metrics.items():
            a=[p['baseline'][key][metric] for p in pairs];b=[p['candidate'][key][metric] for p in pairs]
            check_distribution(summary['baseline'],a);check_distribution(summary['candidate'],b);distributions+=2
            if all(v>0 for v in b):check_distribution(summary['paired_baseline_over_candidate'],[x/y for x,y in zip(a,b)]);distributions+=1
    for c in r['commands']:
        assert c['exit_code']==0
        for stream in ['stdout','stderr']:assert sha(directory/c[stream])==c[stream+'_sha256']
    reports[label]={'commands':len(r['commands']),'distributions':distributions,'report_sha256':sha(directory/'report.json'),'passed':True}
directory=pathlib.Path('/tmp/keyhunt-c17-groups-live');r=json.loads((directory/'report.json').read_text());assert r['passed']
for c in r['commands']:
    for stream in ['stdout','stderr']:assert sha(directory/c[stream])==c[stream+'_sha256']
for s in r['cases'][0]['samples']:
    assert s['metrics']['actual_groups']==[1,8]
    if s['variant']=='timed':
        groups=s['summary']['bsgs_groups'];assert [g['batches'] for g in groups]==[2,2]
        assert sum(int(g['verified_device_steps'],16) for g in groups)==524288
reports['mixed_groups']={'commands':len(r['commands']),'samples':len(r['cases'][0]['samples']),'report_sha256':sha(directory/'report.json'),'passed':True}
directory=pathlib.Path('/tmp/keyhunt-c17-final-profile');r=json.loads((directory/'report.json').read_text());assert r['passed']
for artifact in r['artifacts']:assert sha(directory/artifact['path'])==artifact['sha256']
reports['profile']={'artifacts':len(r['artifacts']),'search_launches':r['trace_search_launches'],'passed':True}
snapshot=json.loads(pathlib.Path('/tmp/keyhunt-c17-final/snapshot.json').read_text())
assert all(sha(root/p)==digest for p,digest in snapshot['source_files_sha256'].items())
assert sha(root/'build/hip-release/keyhunt')==snapshot['binary_sha256']
report={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':True,'source_hashes_match_final_build':True,'checks':reports}
(root/'docs/baselines/C17_EVIDENCE_CHECK.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
