import hashlib,json,re,tarfile,xml.etree.ElementTree as ET
from pathlib import Path
repo=Path('/home/bagus/keyhunt-GPU');raw=Path('/var/tmp/keyhunt-c23-scalar-dance-evidence');out=repo/'docs/baselines'
source='c96dc0fcf12d58ac1c43b87a35e485f46211b8c4'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
manifest=dict(feature='C23 scalar dance batch traversal',source_commit=source,previous_acceptance='f94a46b992924497cf7040484d920bc046a5aaa6',passed=True,phases=dict(contract='890eb82',implementation='7f03433',native='b2c91bf',recovery='fb681a3',workers='dcee3af',example='2a5ec89',guides='b448b6b',contract_status='c96dc0f'),suites={},artifacts={})
for kind,count in [('local',183),('sanitizer',6),('hip',19),('cuda',19)]:
 directory=raw/kind;xml=ET.parse(directory/'tests.xml').getroot();tests=xml.findall('testcase')
 assert len(tests)==count,(kind,len(tests))
 assert 'Passed 240 scalar both-ends recovery combinations' in (directory/'LastTest.log').read_text()
 assert 'Passed 400 scalar dance recovery combinations' in (directory/'LastTest.log').read_text()
 assert all(t.find('failure') is None and t.find('skipped') is None for t in tests),kind
 meta=read(directory/'build-metadata.json');assert meta['source_commit']==source
 manifest['suites'][kind]=dict(tests=count,seconds=xml.get('time'),ctest_seconds=float(re.search(r'Total Test time \(real\) = ([0-9.]+) sec',(directory/'tests.log').read_text())[1]),metadata=meta,results=[dict(name=t.get('name'),seconds=t.get('time')) for t in tests])
algorithms={};recovery={};workers={};examples={}
for kind in ('local','hip','cuda'):
 directory=raw/kind;meta=manifest['suites'][kind]['metadata'];binary=meta['binaries']['keyhunt']
 algorithms[kind]={};recovery[kind]={};workers[kind]={}
 for p in sorted(directory.glob('*.json')):
  name=p.name
  if not any(name.startswith(v) for v in ('scalar-dance-','scalar-batch-oracle','checkpoint-scalar-dance','coordinator-scalar-dance')):continue
  v=read(p);assert v['passed'],p
  if name=='scalar-batch-oracle.json':assert v['binary_sha256']==meta['binaries']['scalar_batch_probe']
  elif 'coordinator-' in name:
   assert v['binaries']['keyhunt']==binary and v['binaries']['keyhunt-worker']==meta['binaries']['keyhunt-worker']
  else:assert v['binary_sha256']==binary,p
  if 'example' in name:
   assert v['document_sha256']==sha(repo/'docs/C23_SCALAR_DANCE.md');examples[kind]=v
  elif name.startswith('checkpoint'):recovery[kind][name]=v
  elif name.startswith('coordinator'):workers[kind][name]=v
  else:algorithms[kind][name]=v
 assert len(algorithms[kind])==5 and len(workers[kind])==2
 assert len(recovery[kind])==(2 if kind=='local' else 3)
san=read(raw/'sanitizer/scalar-batch-oracle.json')
assert san['passed'] and san['cases']==2174
assert san['binary_sha256']==manifest['suites']['sanitizer']['metadata']['binaries']['scalar_batch_probe']
for kind in ('hip','cuda'):
 for name,count in [('strides-forward',203),('strides-reverse',203),('orbits-forward',103),('orbits-reverse',98)]:
  value=algorithms[kind]['scalar-dance-'+name+'.json']
  assert len(value['cases'])==count and len(value['inventory']['devices'])==8
 for value in workers[kind].values():assert len(value['cases'])==8
 for name,value in recovery[kind].items():assert len(value['cases'])==(4 if 'pause' in name else 28)
assert all(v['cases']==2174 and v['max_owners']==3 for kind in algorithms for name,v in algorithms[kind].items() if name=='scalar-batch-oracle.json')
for title,value in [('ALGORITHMS',algorithms),('RECOVERY',recovery),('WORKERS',workers),('EXAMPLES',examples)]:
 p=out/f'C23_SCALAR_DANCE_{title}.json';p.write_text(json.dumps(value,indent=2)+'\n');manifest['artifacts'][p.name]=sha(p)
archive=out/'C23_SCALAR_DANCE_LOGS.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(raw.rglob('*')):
  if p.is_file():tar.add(p,arcname=str(p.relative_to(raw)),recursive=False)
manifest['artifacts'][archive.name]=sha(archive)
manifest['raw_files']={str(p.relative_to(raw)):sha(p) for p in sorted(raw.rglob('*')) if p.is_file()}
manifest['decisions']=[
 'Dance fixes the midpoint of the missing envelope once per invocation, splits crossing gaps before reservations, and uses a logarithmic middle lookup with low fallback.',
 'The phase advances only on accepted batches; high orbit selections retain the existing lower variant-boundary clip.',
 'At most three original work owners stay live; restarting computes a new pivot from the saved complement and can switch between all three scalar batch orders.',
 'Scalar mapping, identities, schema, receipts, protocols and capabilities are unchanged; this is execution policy only.',
 'The native corpus adds unmapped unit-stride forward dance cases as well as mapped strides, reverse order and six-member orbits.'
]
manifest['development_findings']=['No production or test failures were observed in the recorded acceptance runs.']
manifest['limits']=['Synthetic public fixtures; no production-scale throughput or discovery-probability claim.','Scalar random-window traversal remains pending.']
(out/'C23_SCALAR_DANCE_VALIDATION.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({kind:sum(len(v.get('cases',[])) for name,v in data.items() if name!='scalar-batch-oracle.json') for kind,data in algorithms.items()}))
print('PASS bound artifacts for',source)
