#pragma once
#include <cstdint>

// Assembly is opt-in and restricted to AMD Clang's gfx942 device pass. Host,
// CUDA, and other HIP code objects keep the shared portable implementation.
#if defined(KEYHUNT_GFX942_CARRY) && defined(__HIP_DEVICE_COMPILE__) && \
    defined(__gfx942__) && defined(__clang__)
#define KEYHUNT_USE_GFX942_CARRY 1
namespace keyhunt::gpu::gfx942 {
// One asm statement owns all eight limbs of a carry/borrow chain. VCC is a
// per-lane carry mask, not a scalar carry shared between work items. Materialize
// its last bit as 0/1 only after the final limb. No memory or EXEC state changes.
// Early-clobber outputs cannot overlap inputs consumed by a later instruction;
// the final limb and flag may overlap inputs because all have then been read.
// Inputs are loaded before any output store, permitting exact in-place aliasing.

__device__ inline __attribute__((always_inline))
void add_words(uint32_t* out, const uint32_t* a, const uint32_t* b, uint32_t& flag) {
    asm(
        "v_add_co_u32 %0, vcc, %9, %17\n\t"
        "v_addc_co_u32 %1, vcc, %10, %18, vcc\n\t"
        "v_addc_co_u32 %2, vcc, %11, %19, vcc\n\t"
        "v_addc_co_u32 %3, vcc, %12, %20, vcc\n\t"
        "v_addc_co_u32 %4, vcc, %13, %21, vcc\n\t"
        "v_addc_co_u32 %5, vcc, %14, %22, vcc\n\t"
        "v_addc_co_u32 %6, vcc, %15, %23, vcc\n\t"
        "v_addc_co_u32 %7, vcc, %16, %24, vcc\n\t"
        "v_cndmask_b32 %8, 0, 1, vcc"
        : "=&v"(out[0]), "=&v"(out[1]), "=&v"(out[2]), "=&v"(out[3]), "=&v"(out[4]), "=&v"(out[5]), "=&v"(out[6]), "=v"(out[7]), "=v"(flag)
        : "v"(a[0]), "v"(a[1]), "v"(a[2]), "v"(a[3]), "v"(a[4]), "v"(a[5]), "v"(a[6]), "v"(a[7]), "v"(b[0]), "v"(b[1]), "v"(b[2]), "v"(b[3]), "v"(b[4]), "v"(b[5]), "v"(b[6]), "v"(b[7])
        : "vcc");
}

__device__ inline __attribute__((always_inline))
void subtract_words(uint32_t* out, const uint32_t* a, const uint32_t* b, uint32_t& flag) {
    asm(
        "v_sub_co_u32 %0, vcc, %9, %17\n\t"
        "v_subb_co_u32 %1, vcc, %10, %18, vcc\n\t"
        "v_subb_co_u32 %2, vcc, %11, %19, vcc\n\t"
        "v_subb_co_u32 %3, vcc, %12, %20, vcc\n\t"
        "v_subb_co_u32 %4, vcc, %13, %21, vcc\n\t"
        "v_subb_co_u32 %5, vcc, %14, %22, vcc\n\t"
        "v_subb_co_u32 %6, vcc, %15, %23, vcc\n\t"
        "v_subb_co_u32 %7, vcc, %16, %24, vcc\n\t"
        "v_cndmask_b32 %8, 0, 1, vcc"
        : "=&v"(out[0]), "=&v"(out[1]), "=&v"(out[2]), "=&v"(out[3]), "=&v"(out[4]), "=&v"(out[5]), "=&v"(out[6]), "=v"(out[7]), "=v"(flag)
        : "v"(a[0]), "v"(a[1]), "v"(a[2]), "v"(a[3]), "v"(a[4]), "v"(a[5]), "v"(a[6]), "v"(a[7]), "v"(b[0]), "v"(b[1]), "v"(b[2]), "v"(b[3]), "v"(b[4]), "v"(b[5]), "v"(b[6]), "v"(b[7])
        : "vcc");
}
} // namespace keyhunt::gpu::gfx942
#endif
