import json
from pathlib import Path
import subprocess
root=Path('/home/bagus/keyhunt-GPU')
out=Path('/tmp/keyhunt-c19-dispatch');out.mkdir(exist_ok=True)
source=out/'dispatch.cpp'
source.write_text('''#if defined(__HIPCC__)
#include <hip/hip_runtime.h>
#endif
#include "common/field.h"
#if defined(KEYHUNT_USE_GFX942_CARRY) != EXPECT_SPECIALIZED
#error "wrong arithmetic dispatch"
#endif
#if defined(__HIPCC__)
__global__
#endif
void check(keyhunt::gpu::Field* out, const keyhunt::gpu::Field* in) {
    keyhunt::gpu::add(out[0], in[0], in[1]);
    keyhunt::gpu::sub(out[1], in[0], in[1]);
}
''')
clang='/opt/rocm/core-10.0/lib/llvm/bin/clang++'
commands=[]
def run(name,args,code=0,message=''):
 p=subprocess.run(args,cwd=root,capture_output=True,text=True)
 (out/(name+'.out')).write_text(p.stdout);(out/(name+'.err')).write_text(p.stderr)
 passed=(p.returncode==code if code==0 else p.returncode!=0) and message in p.stdout+p.stderr
 commands.append(dict(name=name,argv=list(map(str,args)),exit_code=p.returncode,passed=passed,expected_diagnostic=message))
 (out/'report.json').write_text(json.dumps(dict(passed=all(c['passed'] for c in commands),commands=commands),indent=2)+'\n')
 assert passed,name
for arch,expected in [('gfx942','1'),('gfx90a','0')]:
 run(arch,[clang,'-x','hip','--offload-arch='+arch,'--offload-device-only','-O3','-c',str(source),'-I'+str(root/'kernels'),'-DKEYHUNT_GFX942_CARRY=1','-DEXPECT_SPECIALIZED='+expected,'-o',str(out/(arch+'.o'))])
run('host',['g++','-std=c++17','-O3','-c',str(source),'-I'+str(root/'kernels'),'-DKEYHUNT_GFX942_CARRY=1','-DEXPECT_SPECIALIZED=0','-o',str(out/'host.o')])
run('cpu-rejection',['cmake','-S',str(root),'-B',str(out/'cpu-rejection'),'-DKEYHUNT_GFX942_CARRY=ON'],1,'requires the native AMD HIP backend')
run('architecture-rejection',['cmake','-S',str(root),'-B',str(out/'architecture-rejection'),'-DKEYHUNT_ENABLE_HIP=ON','-DKEYHUNT_GFX942_CARRY=ON','-DCMAKE_HIP_COMPILER='+clang,'-DCMAKE_HIP_ARCHITECTURES=gfx90a'],1,'requires AMD Clang and a gfx942 code object')
print('All five dispatch/configuration checks passed')
