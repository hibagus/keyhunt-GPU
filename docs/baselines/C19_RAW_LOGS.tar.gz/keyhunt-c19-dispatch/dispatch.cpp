#if defined(__HIPCC__)
#include <hip/hip_runtime.h>
#endif
#include "common/field.h"
#if defined(KEYHUNT_USE_GFX942_CARRY) != EXPECT_SPECIALIZED
#error "wrong arithmetic dispatch"
#endif
#if defined(__HIPCC__)
__global__
#endif
void check(keyhunt::gpu::Field* out, const keyhunt::gpu::Field* in) {
    keyhunt::gpu::add(out[0], in[0], in[1]);
    keyhunt::gpu::sub(out[1], in[0], in[1]);
}
