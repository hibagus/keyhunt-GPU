"""Validate retained measurements and collect C19 evidence (kept in raw archive)."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import sys
sys.path.insert(0, '/home/bagus/keyhunt-GPU/tools')
from benchmark_gpu_pair import paired_statistics

root=Path('/home/bagus/keyhunt-GPU');dest=root/'docs/baselines'
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
checks={'passed':True,'paired_reports':0,'metric_distributions':0,'command_log_pairs':0,'isa_files':0}
pairs=[('mad-pair','MAD_REJECTED'),('carry-asm-pair','CARRY_ASM'),('carry-intrinsic-pair','CARRY'),('carry-choice','CARRY_CHOICE'),('cli-pair','CLI'),('direct-pair','DIRECT')]
for suffix,name in pairs:
 directory=Path('/tmp/keyhunt-c19-'+suffix)
 r=json.loads((directory/'report.json').read_text())
 assert r['passed'] and not r['failures'],name
 expected=paired_statistics([p for p in r['pairs'] if not p['warmup']])
 assert expected==r['statistics'],name
 checks['paired_reports']+=1
 checks['metric_distributions']+=sum(len(metrics) for metrics in expected.values())
 for command in r['commands']:
  for stream in ['stdout','stderr']:
   assert sha(directory/command[stream])==command[stream+'_sha256'],command
  checks['command_log_pairs']+=1
 (dest/('C19_'+name+'.json')).write_text(json.dumps(r,indent=2)+'\n')
for variant in ['before','carry-asm','carry-intrinsic','mad']:
 directory=Path('/tmp/keyhunt-c19-isa-'+variant)
 r=json.loads((directory/'report.json').read_text());assert r['passed']
 for obj in r['code_objects']:
  assert sha(directory/obj['file'])==obj['sha256'];checks['isa_files']+=1
 for command in r['commands']:
  for stream in ['stdout','stderr']:
   assert sha(directory/command[stream])==command[stream+'_sha256'];checks['isa_files']+=1

snapshot=json.loads(Path('/tmp/keyhunt-c19-validated/snapshot.json').read_text())
for path,digest in snapshot['source_files_sha256'].items():assert sha(root/path)==digest,path
measured=json.loads((dest/'C19_CARRY.json').read_text())['snapshots']['candidate']
assert snapshot['binaries']==measured['binaries']
assert sha(root/'build/hip-release/keyhunt')==snapshot['binaries']['keyhunt']
checks['current_source_files']=len(snapshot['source_files_sha256'])
checks['final_binaries_equal_measured']=True
pause=json.loads(Path('/tmp/keyhunt-c19-pause.json').read_text());assert pause['passed']
assert pause['binary_sha256']==snapshot['binaries']['keyhunt']
(dest/'C19_PAUSE.json').write_text(json.dumps(pause,indent=2)+'\n')

tests={}
for suite,count in [('cpu',33),('hip',59),('portable',2),('debug',4),('sanitizer',4)]:
 path=Path('/tmp/keyhunt-c19-'+suite+'-tests.log')
 text=path.read_text()
 assert f'100% tests passed, 0 tests failed out of {count}' in text,(suite,text[-2000:])
 tests[suite]={'passed':count,'failed':0,'log':str(path),'log_sha256':sha(path),'output':text}
reports={}
for backend in ['portable','hip','hip_portable']:
 for op in ['field','point']:
  name=f'{backend}-{op}-oracle-results.json'
  path=root/'build/hip-release'/name
  report=json.loads(path.read_text());assert report['failure_count']==0
  reports[backend+'_'+op]=report
  stats=path.with_suffix('.stats.json')
  # Probe stats are already embedded in the oracle report.
  (dest/('C19_'+backend.upper()+'_'+op.upper()+'.json')).write_text(json.dumps(report,indent=2)+'\n')
dispatch=json.loads(Path('/tmp/keyhunt-c19-dispatch/report.json').read_text());assert dispatch['passed']
manifest={'milestone':'C19','recorded_utc':datetime.now(timezone.utc).isoformat(),
 'passed':True,'variant':'opt-in gfx942 carry/borrow compiler intrinsics',
 'binary_sha256':snapshot['binaries']['keyhunt'],'snapshot':snapshot,
 'tests':tests,'oracle_cases':{k:v['cases'] for k,v in reports.items()},'dispatch_checks':dispatch,
 'test_sources_sha256':{str(p.relative_to(root)):sha(p) for p in [root/'tests/gpu/arithmetic_cases.h',root/'tests/gpu/arithmetic_probe.cpp',root/'tests/gpu/field_oracle.py']},
 'limitations':['Single MI300X SPX/NPS1 timing device on an unreserved host.',
 'No new NVIDIA hardware validation, partition change, or multi-GPU scaling claim.',
 '59 HIP/coordinator regression tests plus two subsequently added real-HIP fallback oracles; no duplicate tests counted.',
 'Focused debug/sanitizer checks do not certify known legacy sanitizer failures.',
 'C15 supervisor findings remain C20 work.']}
(dest/'C19_VALIDATION.json').write_text(json.dumps(manifest,indent=2)+'\n')
(dest/'C19_EVIDENCE_CHECK.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(checks,indent=2))
