	.amdgcn_target "amdgcn-amd-amdhsa--gfx942"
	.amdhsa_code_object_version 6
	.text
	.protected	_Z9add_wordsPjPKjS1_    ; -- Begin function _Z9add_wordsPjPKjS1_
	.globl	_Z9add_wordsPjPKjS1_
	.p2align	8
	.type	_Z9add_wordsPjPKjS1_,@function
_Z9add_wordsPjPKjS1_:                   ; @_Z9add_wordsPjPKjS1_
	.cfi_startproc
; %bb.0:
	.cfi_escape 0x0f, 0x04, 0x30, 0x36, 0xe9, 0x02 ; CFA is 0 in private_wave aspace
	.cfi_undefined 16
	s_load_dwordx4 s[4:7], s[0:1], 0x0
	s_load_dwordx2 s[2:3], s[0:1], 0x10
	v_lshlrev_b32_e32 v1, 5, v0
	v_mul_u32_u24_e32 v0, 9, v0
	v_lshlrev_b32_e32 v4, 2, v0
	s_waitcnt lgkmcnt(0)
	global_load_dword v2, v1, s[6:7]
	global_load_dword v3, v1, s[2:3]
	s_waitcnt vmcnt(0)
	v_add_co_u32_e32 v0, vcc, v2, v3
	global_store_dword v4, v0, s[4:5]
	global_load_dword v0, v1, s[6:7] offset:4
	s_nop 0
	global_load_dword v2, v1, s[2:3] offset:4
	s_waitcnt vmcnt(0)
	v_addc_co_u32_e32 v0, vcc, v0, v2, vcc
	global_store_dword v4, v0, s[4:5] offset:4
	global_load_dword v0, v1, s[6:7] offset:8
	s_nop 0
	global_load_dword v2, v1, s[2:3] offset:8
	s_waitcnt vmcnt(0)
	v_addc_co_u32_e32 v0, vcc, v0, v2, vcc
	global_store_dword v4, v0, s[4:5] offset:8
	global_load_dword v0, v1, s[6:7] offset:12
	s_nop 0
	global_load_dword v2, v1, s[2:3] offset:12
	s_waitcnt vmcnt(0)
	v_addc_co_u32_e32 v0, vcc, v0, v2, vcc
	global_store_dword v4, v0, s[4:5] offset:12
	global_load_dword v0, v1, s[6:7] offset:16
	s_nop 0
	global_load_dword v2, v1, s[2:3] offset:16
	s_waitcnt vmcnt(0)
	v_addc_co_u32_e32 v0, vcc, v0, v2, vcc
	global_store_dword v4, v0, s[4:5] offset:16
	global_load_dword v0, v1, s[6:7] offset:20
	s_nop 0
	global_load_dword v2, v1, s[2:3] offset:20
	s_waitcnt vmcnt(0)
	v_addc_co_u32_e32 v0, vcc, v0, v2, vcc
	global_store_dword v4, v0, s[4:5] offset:20
	global_load_dword v0, v1, s[6:7] offset:24
	s_nop 0
	global_load_dword v2, v1, s[2:3] offset:24
	s_waitcnt vmcnt(0)
	v_addc_co_u32_e32 v0, vcc, v0, v2, vcc
	global_store_dword v4, v0, s[4:5] offset:24
	global_load_dword v0, v1, s[6:7] offset:28
	s_nop 0
	global_load_dword v2, v1, s[2:3] offset:28
	s_waitcnt vmcnt(0)
	v_addc_co_u32_e32 v0, vcc, v0, v2, vcc
	s_nop 1
	v_cndmask_b32_e64 v1, 0, 1, vcc
	global_store_dwordx2 v4, v[0:1], s[4:5] offset:28
	s_endpgm
.Lfunc_end0:
	.size	_Z9add_wordsPjPKjS1_, .Lfunc_end0-_Z9add_wordsPjPKjS1_
	.cfi_endproc
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel _Z9add_wordsPjPKjS1_
		.amdhsa_group_segment_fixed_size 0
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 24
		.amdhsa_user_sgpr_count 2
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_kernarg_preload_length 0
		.amdhsa_user_sgpr_kernarg_preload_offset 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_enable_private_segment 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 5
		.amdhsa_next_free_sgpr 8
		.amdhsa_accum_offset 8
		.amdhsa_reserve_vcc 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_tg_split 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
                                        ; -- End function
	.set .L_Z9add_wordsPjPKjS1_.num_vgpr, 5
	.set .L_Z9add_wordsPjPKjS1_.num_agpr, 0
	.set .L_Z9add_wordsPjPKjS1_.numbered_sgpr, 8
	.set .L_Z9add_wordsPjPKjS1_.num_named_barrier, 0
	.set .L_Z9add_wordsPjPKjS1_.private_seg_size, 0
	.set .L_Z9add_wordsPjPKjS1_.uses_vcc, 1
	.set .L_Z9add_wordsPjPKjS1_.uses_flat_scratch, 0
	.set .L_Z9add_wordsPjPKjS1_.has_dyn_sized_stack, 0
	.set .L_Z9add_wordsPjPKjS1_.has_recursion, 0
	.set .L_Z9add_wordsPjPKjS1_.has_indirect_call, 0
	.section	.AMDGPU.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 332
; TotalNumSgprs: 14
; NumVgprs: 5
; NumAgprs: 0
; TotalNumVgprs: 5
; ScratchSize: 0
; MemoryBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 0 bytes/workgroup (compile time only)
; SGPRBlocks: 1
; VGPRBlocks: 0
; NumSGPRsForWavesPerEU: 14
; NumVGPRsForWavesPerEU: 5
; AccumOffset: 8
; Occupancy: 8
; WaveLimiterHint : 0
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 2
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
; COMPUTE_PGM_RSRC3_GFX90A:ACCUM_OFFSET: 1
; COMPUTE_PGM_RSRC3_GFX90A:TG_SPLIT: 0
	.text
	.p2alignl 6, 3212836864
	.fill 256, 4, 3212836864
	.section	.AMDGPU.gpr_maximums,"",@progbits
	.set amdgpu.max_num_vgpr, 0
	.set amdgpu.max_num_agpr, 0
	.set amdgpu.max_num_sgpr, 0
	.set amdgpu.max_num_named_barrier, 0
	.text
	.type	__hip_cuid_72e2f334ede1cdc2,@object ; @__hip_cuid_72e2f334ede1cdc2
	.section	.bss,"aw",@nobits
	.globl	__hip_cuid_72e2f334ede1cdc2
__hip_cuid_72e2f334ede1cdc2:
	.byte	0                               ; 0x0
	.size	__hip_cuid_72e2f334ede1cdc2, 1

	.ident	"AMD clang version 23.0.0git (https://github.com/ROCm/llvm-project.git 8f497e0992fb7513f7f78a6f6b6f1056c375e961)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym __hip_cuid_72e2f334ede1cdc2
	.amdgpu_metadata
---
amdhsa.kernels:
  - .agpr_count:     0
    .args:
      - .address_space:  global
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         8
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         16
        .size:           8
        .value_kind:     global_buffer
    .gfx1250_revision: B0
    .group_segment_fixed_size: 0
    .kernarg_segment_align: 8
    .kernarg_segment_size: 24
    .language:       OpenCL C
    .language_version:
      - 2
      - 0
    .max_flat_workgroup_size: 1024
    .name:           _Z9add_wordsPjPKjS1_
    .private_segment_fixed_size: 0
    .sgpr_count:     14
    .sgpr_spill_count: 0
    .symbol:         _Z9add_wordsPjPKjS1_.kd
    .uniform_work_group_size: 1
    .uses_dynamic_stack: false
    .vgpr_count:     5
    .vgpr_spill_count: 0
    .wavefront_size: 64
amdhsa.target:   amdgcn-amd-amdhsa--gfx942
amdhsa.version:
  - 1
  - 2
...

	.end_amdgpu_metadata
